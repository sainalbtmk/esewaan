<?php
    $isEdit = isset($contract);
    $parent = $parentContract ?? null;
    $parentPremise = $parent?->premise;
    $isFollowUp = $isEdit && $contract->isFollowUpApplication() && $parent;
    $isLanjutan = $isFollowUp && $contract->isLanjutan();
    $lockKeluasan = $isLanjutan;
    $parentRent = $parentPremise?->kadar_sewa ?? $parent?->kadar_sewa_bulanan;

    $kadarSewaValue = old('kadar_sewa');
    if ($kadarSewaValue === null) {
        $kadarSewaValue = $contract?->premise?->kadar_sewa;
        if ($kadarSewaValue === null) {
            $contractRate = $contract?->kadar_sewa_bulanan;
            $kadarSewaValue = ($contractRate !== null && (float) $contractRate > 0)
                ? $contractRate
                : '';
        }
    }

    $keluasanValue = old('keluasan_mp');
    if ($keluasanValue === null) {
        $keluasanValue = $contract?->keluasan_mp;

        if ($keluasanValue === null && $isLanjutan) {
            $keluasanValue = $parent?->keluasan_mp;
        }

        $keluasanValue = $keluasanValue ?? '';
    }

    $keluasanKpsValue = filled($keluasanValue)
        ? number_format((float) $keluasanValue * 10.7639, 2, '.', '')
        : '';

    $sahSehinggaValue = old('sah_sehingga', $contract?->sah_sehingga?->format('Y-m-d') ?? '');
    $tarikhMulaTawaranValue = old('tarikh_mula_tawaran', $contract?->tarikh_mula_tawaran?->format('Y-m-d') ?? '');
    $parentBakiBulan = $parent ? \App\Support\RentalStatusReport::bakiBulan($parent) : null;
?>

<?php $__env->startSection('title', $isFollowUp ? 'Permohonan '.\App\Support\ApplicationCategories::label($contract->kategori_permohonan) : ($isEdit ? 'Kemaskini Permohonan' : 'Permohonan Baru')); ?>
<?php $__env->startSection('header_title', $isFollowUp ? 'Permohonan '.\App\Support\ApplicationCategories::label($contract->kategori_permohonan) : ($isEdit ? 'Kemaskini Permohonan' : 'Permohonan Baru')); ?>
<?php $__env->startSection('header_subtitle', $isFollowUp ? 'Lengkapkan maklumat baharu dan langkah tindakan untuk permohonan susulan' : ($isEdit ? 'Kemaskini maklumat borang dan langkah tindakan dalam satu halaman' : 'Isi maklumat borang permohonan sewaan baharu')); ?>

<?php $__env->startSection('content'); ?>
<div>
    <form
        id="form-sewaan"
        method="POST"
        action="<?php echo e($isEdit ? route('application.update', $contract) : route('application.store')); ?>"
        class="block space-y-6"
        <?php if($isEdit && isset($stepPanels)): ?>
            data-autosave-url="<?php echo e(route('application.autosave', $contract)); ?>"
            data-initial-step="<?php echo e($initialStep ?? $step); ?>"
            data-active-steps="<?php echo e(json_encode($activeSteps)); ?>"
            data-remark-required="<?php echo e($isFollowUp ? '1' : '0'); ?>"
        <?php endif; ?>
    >
        <?php echo csrf_field(); ?>
        <?php if($isEdit): ?>
            <?php echo method_field('PUT'); ?>
            <?php if(isset($stepPanels)): ?>
                <input type="hidden" name="current_step" id="current-step-input" value="<?php echo e($initialStep ?? $step); ?>">
            <?php endif; ?>
        <?php endif; ?>

        <?php if($isFollowUp): ?>
            <section class="glass-panel-muted overflow-hidden">
                <div class="border-b border-slate-200/80 px-6 py-4">
                    <h2 class="text-lg font-semibold text-slate-800">Maklumat Kontrak Sedia Ada</h2>
                </div>
                <div class="px-6 py-5">
                    <div class="pointer-events-none grid grid-cols-1 gap-3 md:grid-cols-3 [&_p]:text-slate-500 [&_.glass-field-static]:border-slate-300/80 [&_.glass-field-static]:bg-slate-100 [&_.glass-field-static]:text-slate-800 [&_.glass-field-static]:shadow-none">
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Nama Premis Lama', 'value' => $parentPremise?->nama_ptj], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Kadar Sewa Lama (RM)', 'value' => $parentRent !== null ? number_format((float) $parentRent, 2) : null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Tarikh Mula Lama', 'value' => $parent?->tarikh_mula_tawaran?->format('d/m/Y')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Tarikh Akhir Tempoh Tawaran Penyewaan Lama', 'value' => $parent?->sah_sehingga?->format('d/m/Y')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Baki Bulan', 'value' => $parentBakiBulan === null ? null : $parentBakiBulan.' bulan'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Jenis Bangunan Lama', 'value' => \App\Support\BuildingTypes::all()[$parentPremise?->jenis_bangunan] ?? $parentPremise?->jenis_bangunan], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Pemilik Lama', 'value' => $parentPremise?->nama_pemilik], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', ['label' => 'Alamat Lama', 'value' => $parentPremise?->alamat_penuh, 'wrapperClass' => 'md:col-span-3', 'multiline' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <section class="glass-card overflow-hidden">
            <div class="glass-divider border-b px-6 py-4">
                <h2 class="text-lg font-semibold text-gray-900">
                    <?php echo e($isFollowUp ? 'Maklumat Baharu' : ($isEdit ? 'Kemaskini Borang Permohonan Sewaan' : 'Borang Permohonan Baru Sewaan')); ?>

                </h2>
                <?php if($isFollowUp): ?>
                    <p class="mt-1 text-xs text-slate-600">Isi maklumat baharu untuk permohonan ini.</p>
                <?php endif; ?>
            </div>

            <div class="px-6 py-5">
                <div class="mx-auto max-w-4xl space-y-6">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <div>
                        <label for="kategori_permohonan" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                            <span>Kategori Permohonan *</span>
                            <?php echo $__env->make('partials.form-field-hint', ['text' => $isEdit
                                ? 'Kategori dikunci selepas permohonan dicipta.'
                                : 'Pindah dan Lanjutan boleh dibuat pada senarai kontrak sewaan yang telah wujud.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </label>
                        <?php
                            $selectedKategori = old(
                                'kategori_permohonan',
                                $isEdit ? $contract->kategori_permohonan : \App\Support\ApplicationCategories::BARU
                            );
                        ?>
                        <?php if($isEdit): ?>
                            <select
                                id="kategori_permohonan"
                                required
                                disabled
                                class="glass-input w-full cursor-not-allowed rounded-xl px-3 py-2 text-sm opacity-70"
                            >
                                <option value="<?php echo e($selectedKategori); ?>" selected>
                                    <?php echo e(\App\Support\ApplicationCategories::label($selectedKategori)); ?>

                                </option>
                            </select>
                            <input type="hidden" name="kategori_permohonan" value="<?php echo e($selectedKategori); ?>">
                            <p class="mt-1.5 text-xs glass-accent-text">
                                Kategori permohonan dikunci selepas permohonan dicipta.
                            </p>
                        <?php else: ?>
                            <select
                                name="kategori_permohonan"
                                id="kategori_permohonan"
                                required
                                class="glass-input w-full rounded-xl px-3 py-2 text-sm"
                                data-kategori-select
                            >
                                <option value="">— Pilih kategori —</option>
                                <?php $__currentLoopData = \App\Support\ApplicationCategories::labels(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($value); ?>"
                                        data-description="<?php echo e(\App\Support\ApplicationCategories::description($value)); ?>"
                                        <?php if($selectedKategori === $value): echo 'selected'; endif; ?>
                                    ><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p id="kategori-permohonan-hint" class="mt-1.5 text-xs glass-accent-text">
                                <?php echo e(\App\Support\ApplicationCategories::description($selectedKategori)); ?>

                            </p>
                        <?php endif; ?>
                        <?php $__errorArgs = ['kategori_permohonan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="negeri" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                            <span>Negeri *</span>
                            <?php echo $__env->make('partials.form-field-hint', ['text' => 'Negeri lokasi premis yang mengikut lokasi pengguna.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </label>
                        <select id="negeri" required disabled class="glass-input w-full cursor-not-allowed rounded-xl px-3 py-2 text-sm text-slate-600">
                            <option value="<?php echo e($adminNegeri); ?>" selected><?php echo e($adminNegeri); ?></option>
                        </select>
                        <input type="hidden" name="negeri" value="<?php echo e(old('negeri', $contract?->premise?->negeri ?? $adminNegeri)); ?>">
                        <?php $__errorArgs = ['negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="daerah" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                            <span>Daerah *</span>
                            <?php echo $__env->make('partials.form-field-hint', ['text' => 'Daerah AADK dipaparkan mengikut negeri yang dipilih.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </label>
                        <select name="daerah" id="daerah" required class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                            <option value="">— Pilih daerah —</option>
                            <?php $__currentLoopData = $daerahList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daerah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($daerah); ?>" <?php if(old('daerah', $contract?->premise?->daerah) === $daerah): echo 'selected'; endif; ?>><?php echo e($daerah); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['daerah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div>
                    <div class="mb-3 flex items-center gap-2">
                        <svg class="h-4 w-4 glass-icon-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                        <p class="text-sm font-semibold text-gray-700">Maklumat Premis</p>
                    </div>
                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div>
                            <label for="nama_ptj" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Nama Premis *</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Nama premis atau pejabat yang hendak disewa, contoh: AADK Daerah Pasir Puteh.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <input type="text" name="nama_ptj" id="nama_ptj" value="<?php echo e(old('nama_ptj', $contract?->premise?->nama_ptj)); ?>" required placeholder="Cth: AADK Daerah Pasir Puteh" class="glass-input w-full rounded-xl px-3 py-2 text-sm placeholder:text-slate-400">
                            <?php $__errorArgs = ['nama_ptj'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="jenis_bangunan" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Jenis Bangunan *</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Pilih kategori bangunan premis: kompleks kerajaan atau komersial.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <select name="jenis_bangunan" id="jenis_bangunan" required class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                                <option value="">— Pilih jenis bangunan —</option>
                                <?php $__currentLoopData = $jenisList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php if(old('jenis_bangunan', $contract?->premise?->jenis_bangunan) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['jenis_bangunan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="kadar_sewa" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Kadar Sewa <?php echo e($isFollowUp ? 'Baharu ' : ''); ?>(RM) *</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Kadar sewa bulanan premis dalam Ringgit Malaysia.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <input
                                type="number"
                                name="kadar_sewa"
                                id="kadar_sewa"
                                value="<?php echo e($kadarSewaValue); ?>"
                                step="0.01"
                                min="0"
                                required
                                placeholder="0.00"
                                <?php if($isFollowUp): ?> data-parent-rent="<?php echo e($parentRent !== null ? (float) $parentRent : ''); ?>" <?php endif; ?>
                                class="glass-input w-full rounded-xl px-3 py-2 text-sm placeholder:text-slate-400"
                            >
                            <?php if($isFollowUp): ?>
                                <p id="rent-diff-badge" class="mt-1.5 hidden text-xs font-medium" data-below-label="Perbezaan < RM500" data-above-label="Perbezaan ≥ RM500"></p>
                            <?php endif; ?>
                            <?php $__errorArgs = ['kadar_sewa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <div class="grid grid-cols-2 gap-3">
                                <div class="min-w-0">
                                    <label for="keluasan_mp" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                        <span>Keluasan (mps) *</span>
                                        <?php echo $__env->make('partials.form-field-hint', ['text' => $lockKeluasan
                                            ? 'Keluasan dikunci mengikut kontrak sedia ada untuk permohonan lanjutan.'
                                            : 'Keluasan premis dalam meter persegi (mps). Akan ditukar automatik kepada kaki persegi (kps).'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </label>
                                    <input
                                        type="number"
                                        name="keluasan_mp"
                                        id="keluasan_mp"
                                        value="<?php echo e($keluasanValue); ?>"
                                        step="0.01"
                                        min="0"
                                        required
                                        <?php if($lockKeluasan): echo 'readonly'; endif; ?>
                                        placeholder="0.00"
                                        data-area-unit="mps"
                                        data-keluasan-locked="<?php echo e($lockKeluasan ? '1' : '0'); ?>"
                                        class="glass-input w-full rounded-xl px-3 py-2 text-sm placeholder:text-slate-400 <?php echo e($lockKeluasan ? 'cursor-not-allowed opacity-70' : ''); ?>"
                                    >
                                    <?php if($lockKeluasan): ?>
                                        <p class="mt-1.5 text-xs glass-accent-text">Dikunci mengikut kontrak sedia ada.</p>
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['keluasan_mp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="min-w-0">
                                    <label for="keluasan_kps" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                        <span>Keluasan (kps) *</span>
                                        <?php echo $__env->make('partials.form-field-hint', ['text' => $lockKeluasan
                                            ? 'Keluasan dikunci mengikut kontrak sedia ada untuk permohonan lanjutan.'
                                            : 'Keluasan premis dalam kaki persegi (kps). Akan ditukar automatik kepada meter persegi (mps). 1 mps ≈ 10.7639 kps.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </label>
                                    <input
                                        type="number"
                                        id="keluasan_kps"
                                        value="<?php echo e($keluasanKpsValue); ?>"
                                        step="0.01"
                                        min="0"
                                        required
                                        <?php if($lockKeluasan): echo 'readonly'; endif; ?>
                                        placeholder="0.00"
                                        data-area-unit="kps"
                                        data-keluasan-locked="<?php echo e($lockKeluasan ? '1' : '0'); ?>"
                                        class="glass-input w-full rounded-xl px-3 py-2 text-sm placeholder:text-slate-400 <?php echo e($lockKeluasan ? 'cursor-not-allowed opacity-70' : ''); ?>"
                                    >
                                </div>
                            </div>
                        </div>
                        <div>
                            <label for="tarikh_mula_tawaran" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Tarikh Mula <?php echo e($isFollowUp ? 'Baharu ' : ''); ?>*</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Tarikh mula tempoh tawaran penyewaan untuk premis ini.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <input
                                type="date"
                                name="tarikh_mula_tawaran"
                                id="tarikh_mula_tawaran"
                                value="<?php echo e($tarikhMulaTawaranValue); ?>"
                                required
                                class="glass-input w-full rounded-xl px-3 py-2 text-sm"
                            >
                            <?php $__errorArgs = ['tarikh_mula_tawaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="sah_sehingga" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Tarikh Akhir Tempoh Tawaran Penyewaan <?php echo e($isFollowUp ? 'Baharu ' : ''); ?>*</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Tarikh akhir tempoh tawaran penyewaan untuk premis ini.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <input
                                type="date"
                                name="sah_sehingga"
                                id="sah_sehingga"
                                value="<?php echo e($sahSehinggaValue); ?>"
                                required
                                class="glass-input w-full rounded-xl px-3 py-2 text-sm"
                            >
                            <?php $__errorArgs = ['sah_sehingga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="md:col-span-2">
                            <label for="alamat_penuh" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Alamat Penuh Premis *</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Alamat lengkap premis termasuk tingkat, jalan, bandar dan poskod.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <textarea name="alamat_penuh" id="alamat_penuh" rows="2" required placeholder="Cth: Tingkat 3, Plaza MARA Lot A-31 Jalan Kota." class="glass-input w-full resize-none rounded-xl px-3 py-2 text-sm placeholder:text-slate-400"><?php echo e(old('alamat_penuh', $contract?->premise?->alamat_penuh)); ?></textarea>
                            <?php $__errorArgs = ['alamat_penuh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="mb-3 flex items-center gap-2">
                        <svg class="h-4 w-4 glass-icon-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                        <p class="text-sm font-semibold text-gray-700">Maklumat Pemilik</p>
                    </div>
                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div>
                            <label for="nama_pemilik" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Nama Pemilik *</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Nama pemilik premis atau agensi pemilik, contoh: Majlis Amanah Rakyat (MARA).'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <input type="text" name="nama_pemilik" id="nama_pemilik" value="<?php echo e(old('nama_pemilik', $contract?->premise?->nama_pemilik)); ?>" required placeholder="Cth: Majlis Amanah Rakyat (MARA)" class="glass-input w-full rounded-xl px-3 py-2 text-sm placeholder:text-slate-400">
                            <?php $__errorArgs = ['nama_pemilik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <?php if($isFollowUp): ?>
                    <div id="remark-field-section">
                        <div class="mb-3 flex items-center gap-2">
                            <svg class="h-4 w-4 glass-icon-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                            <p class="text-sm font-semibold text-gray-700">Remark</p>
                        </div>
                        <div>
                            <label for="remark" class="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <span>Remark *</span>
                                <?php echo $__env->make('partials.form-field-hint', ['text' => 'Catatan wajib berkaitan permohonan '.strtolower(\App\Support\ApplicationCategories::label($contract->kategori_permohonan)).' ini.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </label>
                            <textarea name="remark" id="remark" rows="2" required placeholder="Masukkan remark..." class="glass-input w-full resize-none rounded-xl px-3 py-2 text-sm placeholder:text-slate-400"><?php echo e(old('remark', $contract?->remark)); ?></textarea>
                            <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if($contract->isAwaitingFollowUpRemark()): ?>
                                <p class="mt-1.5 text-xs font-medium text-amber-700">Remark diperlukan sebelum permohonan boleh dihantar ke Ibu Pejabat.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </section>

        <?php if($isEdit && isset($stepPanels)): ?>
            <section class="glass-card overflow-hidden">
                <?php echo $__env->make('application.partials.proceed-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </section>
        <?php endif; ?>

        <section class="glass-card overflow-hidden">
            <div class="flex flex-wrap items-center justify-between gap-3 px-6 py-4">
            <?php if($isFollowUp): ?>
                <button
                    type="submit"
                    form="cancel-follow-up-form"
                    class="text-sm font-medium text-red-600 transition-colors hover:text-red-700"
                    data-confirm-click="Batalkan permohonan <?php echo e(\App\Support\ApplicationCategories::label($contract->kategori_permohonan)); ?> ini dan kembali ke kontrak asal? Semua maklumat yang dimasukkan akan dibuang."
                >
                    Batal permohonan susulan
                </button>
            <?php else: ?>
                <span></span>
            <?php endif; ?>

            <div class="flex flex-wrap items-center justify-end gap-3">
            <?php if($isEdit && isset($stepPanels)): ?>
                <?php if($contract->isAwaitingFollowUpRemark()): ?>
                    <p class="text-sm font-medium text-amber-700">Sila isi Remark sebelum menghantar ke Ibu Pejabat.</p>
                <?php endif; ?>

                <p id="form-save-status" class="mr-auto hidden text-xs text-slate-500" aria-live="polite"></p>

                <?php echo $__env->make('application.partials.proceed-save-buttons', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div id="submit-hq-wrap" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['contents' => $contract->isReadyToSendToHq(), 'hidden' => ! $contract->isReadyToSendToHq()]); ?>">
                    <button
                        type="button"
                        id="submit-hq-button"
                        class="status-confirm-trigger glass-btn-primary rounded-xl px-5 py-2 text-sm font-medium"
                        data-confirm-title="Hantar Permohonan ke Ibu Pejabat"
                        data-confirm-message="Anda pasti mahu menghantar permohonan ini kepada Ibu Pejabat untuk semakan? Sila semak maklumat premis sebelum meneruskan."
                        data-confirm-form="submit-hq-form"
                        data-confirm-button="Ya, Hantar"
                        data-confirm-tone="success"
                    >
                        Hantar ke Ibu Pejabat
                    </button>
                </div>
            <?php else: ?>
            <button type="submit" class="glass-btn-primary rounded-xl px-5 py-2 text-sm font-medium disabled:opacity-60">
                <?php if($isEdit): ?>
                    Simpan
                <?php else: ?>
                    Teruskan ke Tindakan
                <?php endif; ?>
            </button>
            <?php endif; ?>
            </div>
            </div>
        </section>
    </form>

    <?php if($isEdit && isset($stepPanels)): ?>
    <form id="submit-hq-form" method="POST" action="<?php echo e(route('status-permohonan.submit-hq', $contract)); ?>" class="hidden">
        <?php echo csrf_field(); ?>
    </form>
    <?php endif; ?>

    <?php if($isFollowUp): ?>
    <form id="cancel-follow-up-form" method="POST" action="<?php echo e(route('kontrak-sewaan.follow-up.cancel', $contract)); ?>" class="hidden">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
    <?php endif; ?>
</div>

<?php echo $__env->make('application.partials.form-required-field-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('application.partials.keluasan-conversion-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php if($isEdit && isset($stepPanels)): ?>
<?php echo $__env->make('partials.confirm-action-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('application.partials.proceed-scripts', [
    'formId' => 'form-sewaan',
    'saveUrl' => route('admin-proceed.update', $contract),
    'redirectWhenComplete' => route('status-permohonan.index'),
    'useFullFormAutosave' => true,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const form = document.getElementById('form-sewaan');
    window.ApplicationFormValidation?.bind(form);

    const modal = document.getElementById('confirm-action-modal');
    const modalTitle = document.getElementById('confirm-action-title');
    const modalMessage = document.getElementById('confirm-action-message');
    const modalDetailsWrap = document.getElementById('confirm-action-details-wrap');
    const modalWithdrawalReasonRow = document.getElementById('confirm-action-withdrawal-reason-row');
    const modalWithdrawalReason = document.getElementById('confirm-action-withdrawal-reason');
    const modalConfirm = document.getElementById('confirm-action-confirm');
    const modalCancel = document.getElementById('confirm-action-cancel');
    const modalIcon = document.getElementById('confirm-action-icon');
    const formSaveStatus = document.getElementById('form-save-status');
    let pendingForm = null;

    const iconTemplates = {
        success: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>',
    };

    function closeConfirmModal() {
        if (!modal) return;
        modal.classList.add('hidden');
        pendingForm = null;
        document.body.classList.remove('overflow-hidden');
    }

    function setConfirmDetails(trigger) {
        const withdrawalReason = (trigger.dataset.confirmWithdrawalReason || '').trim();
        const showWithdrawalReason = withdrawalReason !== '';

        if (modalWithdrawalReasonRow) {
            modalWithdrawalReasonRow.classList.toggle('hidden', !showWithdrawalReason);
        }

        if (modalWithdrawalReason) {
            modalWithdrawalReason.textContent = withdrawalReason || '–';
        }

        if (modalDetailsWrap) {
            modalDetailsWrap.classList.toggle('hidden', !showWithdrawalReason);
        }
    }

    function showFormStatus(message) {
        if (!formSaveStatus) return;
        formSaveStatus.textContent = message;
        formSaveStatus.classList.remove('hidden');
        window.setTimeout(() => formSaveStatus.classList.add('hidden'), 3000);
    }

    document.querySelectorAll('.status-confirm-trigger').forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const targetForm = document.getElementById(trigger.dataset.confirmForm);
            if (!targetForm || !modal || !modalConfirm || !modalTitle || !modalMessage) return;

            if (trigger.id === 'submit-hq-button' && form && !window.ApplicationFormValidation?.validate(form)) {
                showFormStatus('Sila lengkapkan semua ruangan yang wajib diisi.');
                return;
            }

            modalTitle.textContent = trigger.dataset.confirmTitle || 'Sahkan Tindakan';
            modalMessage.textContent = trigger.dataset.confirmMessage || '';
            setConfirmDetails(trigger);
            modalConfirm.textContent = trigger.dataset.confirmButton || 'Sahkan';
            modalConfirm.className = 'glass-btn-success rounded-xl px-4 py-2 text-sm font-medium';

            if (modalIcon) {
                modalIcon.className = 'mb-4 flex h-11 w-11 items-center justify-center rounded-full bg-emerald-50 text-emerald-600';
                modalIcon.innerHTML = iconTemplates.success;
            }

            pendingForm = targetForm;
            modal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden');
            modalConfirm.focus();
        });
    });

    modalCancel?.addEventListener('click', closeConfirmModal);
    modalConfirm?.addEventListener('click', () => {
        pendingForm?.submit();
        closeConfirmModal();
    });
    modal?.querySelectorAll('[data-confirm-dismiss]').forEach((el) => el.addEventListener('click', closeConfirmModal));
})();
</script>
<?php $__env->stopPush(); ?>
<?php else: ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const form = document.getElementById('form-sewaan');
    window.ApplicationFormValidation?.bind(form);

    form?.addEventListener('submit', (event) => {
        if (!window.ApplicationFormValidation?.validate(form)) {
            event.preventDefault();
        }
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php if (! ($isEdit)): ?>
<script>
    (function () {
        const select = document.querySelector('[data-kategori-select]');
        const hint = document.getElementById('kategori-permohonan-hint');
        if (!select || !hint) {
            return;
        }

        const updateHint = () => {
            const selected = select.options[select.selectedIndex];
            hint.textContent = selected?.dataset?.description
                || 'Sila pilih kategori permohonan.';
        };

        select.addEventListener('change', updateHint);
        updateHint();
    })();
</script>
<?php endif; ?>

<?php if($isFollowUp): ?>
<script>
    (function () {
        const input = document.getElementById('kadar_sewa');
        const badge = document.getElementById('rent-diff-badge');
        if (!input || !badge) {
            return;
        }

        const parentRent = parseFloat(input.dataset.parentRent);
        if (isNaN(parentRent)) {
            return;
        }

        const threshold = 500;
        const format = (value) => value.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        const update = () => {
            const value = parseFloat(input.value);
            if (isNaN(value)) {
                badge.classList.add('hidden');
                return;
            }

            const difference = value - parentRent;
            const magnitude = Math.abs(difference);
            const isBelow = magnitude < threshold;
            const label = isBelow ? badge.dataset.belowLabel : badge.dataset.aboveLabel;
            const sign = difference > 0 ? '+' : (difference < 0 ? '−' : '');

            badge.textContent = `${label} — Lama RM${format(parentRent)} → Baharu RM${format(value)} (${sign}RM${format(magnitude)})`;
            badge.classList.remove('hidden', 'text-emerald-700', 'text-amber-700');
            badge.classList.add(isBelow ? 'text-emerald-700' : 'text-amber-700');
        };

        input.addEventListener('input', update);
        update();
    })();
</script>
<?php endif; ?>

<?php if($isFollowUp && session('error')): ?>
<script>
    document.getElementById('remark-field-section')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/application/form.blade.php ENDPATH**/ ?>