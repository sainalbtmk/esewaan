<div id="proceed-section">
    <div class="glass-divider border-b px-6 py-4">
        <h2 class="text-lg font-semibold text-slate-900">Langkah Tindakan</h2>
        <p class="mt-1 text-xs text-slate-600">
            Lengkapkan semua langkah tindakan sebelum menghantar permohonan kepada Ibu Pejabat.
        </p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-[minmax(240px,280px)_1fr]">
        <aside class="glass-divider border-b px-4 py-5 sm:px-5 lg:border-b-0 lg:border-r lg:py-6">
            <?php echo $__env->make('partials.admin-proceed-stepper', [
                'contract' => $contract,
                'step' => $initialStep ?? $step,
                'progress' => $progress,
                'completedCount' => $completedCount,
                'activeSteps' => $activeSteps,
                'clientNavigation' => true,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>

        <div class="min-w-0 px-6 py-6">
            <?php $__currentLoopData = $stepPanels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    id="proceed-step-panel-<?php echo e($panel['number']); ?>"
                    class="proceed-step-panel mx-auto max-w-2xl <?php echo e(($initialStep ?? $step) === $panel['number'] ? '' : 'hidden'); ?>"
                    data-step="<?php echo e($panel['number']); ?>"
                    data-step-key="<?php echo e($panel['key']); ?>"
                    <?php if($panel['has_agency_checklist']): ?> data-requires-agencies="1" <?php endif; ?>
                    <?php if($panel['key'] === \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?> data-confirmations-complete-step="1" <?php endif; ?>
                >
                    <div class="mb-5">
                        <p class="text-xs font-medium uppercase tracking-wide text-slate-500">Langkah <?php echo e($panel['position']); ?> / <?php echo e($totalActiveSteps); ?></p>
                        <h3 class="mt-1 text-lg font-semibold text-slate-900"><?php echo e($panel['title']); ?></h3>
                        <p class="mt-2 text-sm leading-relaxed text-slate-600"><?php echo e($panel['description']); ?></p>
                    </div>

                    <?php if($panel['has_agency_checklist']): ?>
                        <div class="proceed-agency-checklist glass-subtle mb-5 rounded-2xl border border-slate-300 p-4">
                            <div class="space-y-2.5">
                                <?php $__currentLoopData = \App\Support\AdminProceedSteps::agencyDefinitions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agencyKey => $agencyLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $agencyChecked = filter_var(
                                            old('proceed_steps.'.$panel['key'].'.agencies.'.$agencyKey, $panel['agencies'][$agencyKey] ?? false),
                                            FILTER_VALIDATE_BOOLEAN
                                        );
                                        $agencyRequiresDate = \App\Support\AdminProceedSteps::agencyRequiresDate($agencyKey);
                                        $agencyDate = old(
                                            'proceed_steps.'.$panel['key'].'.agency_dates.'.$agencyKey,
                                            $panel['agency_dates'][$agencyKey] ?? null
                                        );
                                    ?>
                                    <div class="flex flex-col gap-2 rounded-xl border border-slate-300 bg-white/50 px-3 py-2 transition-colors hover:border-slate-400 hover:bg-white/70 sm:flex-row sm:items-center sm:justify-between">
                                        <label class="flex min-w-0 cursor-pointer items-start gap-3">
                                            <input
                                                type="checkbox"
                                                name="proceed_steps[<?php echo e($panel['key']); ?>][agencies][<?php echo e($agencyKey); ?>]"
                                                value="1"
                                                <?php if($agencyChecked): echo 'checked'; endif; ?>
                                                class="proceed-agency-checkbox mt-0.5 h-4 w-4 shrink-0 rounded border-white/60 text-slate-800 focus:ring-slate-500/30"
                                                data-agency-key="<?php echo e($agencyKey); ?>"
                                                <?php if($agencyRequiresDate): ?> data-requires-date="1" <?php endif; ?>
                                            >
                                            <span class="text-sm text-slate-700"><?php echo e($agencyLabel); ?></span>
                                        </label>
                                        <?php if($agencyRequiresDate): ?>
                                            <div
                                                class="proceed-agency-date-wrap ml-7 sm:ml-0 <?php echo e($agencyChecked ? '' : 'hidden'); ?>"
                                                data-agency-date-for="<?php echo e($agencyKey); ?>"
                                            >
                                                <label class="sr-only" for="proceed_agency_date_<?php echo e($panel['key']); ?>_<?php echo e($agencyKey); ?>">Tarikh surat <?php echo e($agencyLabel); ?></label>
                                                <input
                                                    type="date"
                                                    id="proceed_agency_date_<?php echo e($panel['key']); ?>_<?php echo e($agencyKey); ?>"
                                                    name="proceed_steps[<?php echo e($panel['key']); ?>][agency_dates][<?php echo e($agencyKey); ?>]"
                                                    value="<?php echo e($agencyDate); ?>"
                                                    class="proceed-agency-date glass-input w-full rounded-lg px-2.5 py-1.5 text-sm sm:w-40"
                                                    data-agency-key="<?php echo e($agencyKey); ?>"
                                                    <?php if(! $agencyChecked): echo 'disabled'; endif; ?>
                                                >
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <p class="proceed-agency-hint mt-3 hidden text-xs text-amber-700">Sila tandakan semua agensi di atas sebelum mengesahkan langkah ini.</p>
                        </div>
                    <?php endif; ?>

                    <?php if($panel['requires_reference'] ?? false): ?>
                        <div class="mb-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
                            <div>
                                <label for="proceed_no_rujukan_<?php echo e($panel['key']); ?>" class="mb-1.5 block text-sm font-medium text-slate-700">No. Rujukan *</label>
                                <input
                                    type="text"
                                    name="proceed_steps[<?php echo e($panel['key']); ?>][no_rujukan]"
                                    id="proceed_no_rujukan_<?php echo e($panel['key']); ?>"
                                    value="<?php echo e(old('proceed_steps.'.$panel['key'].'.no_rujukan', $panel['no_rujukan'] ?? '')); ?>"
                                    required
                                    maxlength="100"
                                    placeholder="Cth: AADK/BKP/PB 200-3/02"
                                    class="proceed-step-no-rujukan glass-input w-full rounded-xl px-3 py-2 text-sm"
                                >
                            </div>
                            <div>
                                <label for="proceed_tarikh_surat_<?php echo e($panel['key']); ?>" class="mb-1.5 block text-sm font-medium text-slate-700">Tarikh Surat *</label>
                                <input
                                    type="date"
                                    name="proceed_steps[<?php echo e($panel['key']); ?>][tarikh_surat]"
                                    id="proceed_tarikh_surat_<?php echo e($panel['key']); ?>"
                                    value="<?php echo e(old('proceed_steps.'.$panel['key'].'.tarikh_surat', $panel['tarikh_surat'] ?? '')); ?>"
                                    required
                                    class="proceed-step-tarikh-surat glass-input w-full rounded-xl px-3 py-2 text-sm"
                                >
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="mb-5 space-y-3">
                        <label class="proceed-step-checkbox-label glass-subtle flex cursor-pointer items-start gap-3 rounded-2xl border border-slate-300 px-4 py-4 transition-all hover:border-slate-400 hover:bg-white/45">
                            <input
                                type="checkbox"
                                name="proceed_steps[<?php echo e($panel['key']); ?>][confirmed_accurate]"
                                value="1"
                                <?php if(old('proceed_steps.'.$panel['key'].'.confirmed_accurate', $panel['confirmed_accurate'] ?? false)): echo 'checked'; endif; ?>
                                class="proceed-step-confirmed-accurate mt-0.5 h-4 w-4 rounded border-white/60 text-slate-800 focus:ring-slate-500/30"
                            >
                            <span class="text-sm text-slate-700">
                                <span class="font-medium text-slate-900">
                                    <?php if($panel['position'] === 1): ?>
                                        Saya mengesahkan surat niat telah dihantar ke pemilik premis
                                    <?php elseif($panel['key'] === \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?>
                                        Saya mengesahkan borang JRP telah diisi dan dimuat naik ke PROMIS
                                    <?php else: ?>
                                        Saya mengesahkan maklumat ini tepat dan benar
                                    <?php endif; ?>
                                </span>
                            </span>
                        </label>

                        <label class="proceed-step-checkbox-label glass-subtle flex cursor-pointer items-start gap-3 rounded-2xl border border-slate-300 px-4 py-4 transition-all hover:border-slate-400 hover:bg-white/45">
                            <input
                                type="checkbox"
                                name="proceed_steps[<?php echo e($panel['key']); ?>][confirmed_promis]"
                                value="1"
                                <?php if(old('proceed_steps.'.$panel['key'].'.confirmed_promis', $panel['confirmed_promis'] ?? false)): echo 'checked'; endif; ?>
                                class="proceed-step-confirmed-promis mt-0.5 h-4 w-4 rounded border-white/60 text-slate-800 focus:ring-slate-500/30"
                            >
                            <span class="text-sm text-slate-700">
                                <span class="font-medium text-slate-900">
                                    <?php if($panel['position'] === 1): ?>
                                        Surat tawaran pemilik premis telah diterima dan dimuat naik ke PROMIS
                                    <?php elseif($panel['key'] === \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?>
                                        Saya mengesahkan maklumat ini tepat dan benar
                                    <?php else: ?>
                                        Maklumat ini telah dimuat naik ke dalam sistem PROMIS.
                                    <?php endif; ?>
                                </span>
                            </span>
                        </label>
                    </div>

                    <?php if($panel['key'] !== \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?>
                    <label class="proceed-step-checkbox-label glass-subtle flex cursor-pointer items-start gap-3 rounded-2xl border border-slate-300 px-4 py-4 transition-all hover:border-slate-400 hover:bg-white/45">
                        <input
                            type="checkbox"
                            name="proceed_steps[<?php echo e($panel['key']); ?>][completed]"
                            value="1"
                            <?php if(old('proceed_steps.'.$panel['key'].'.completed', $panel['marked_complete'] ?? $panel['completed'])): echo 'checked'; endif; ?>
                            class="proceed-step-completed mt-0.5 h-4 w-4 rounded border-white/60 text-slate-800 focus:ring-slate-500/30"
                        >
                        <span class="text-sm text-slate-700">
                            <span class="font-medium text-slate-900">Saya mengesahkan langkah ini telah selesai dilaksanakan.</span>
                        </span>
                    </label>
                    <?php endif; ?>

                    <div class="mt-5">
                        <label for="proceed_notes_<?php echo e($panel['key']); ?>" class="mb-1.5 block text-sm font-medium text-slate-700">Catatan</label>
                        <textarea
                            name="proceed_steps[<?php echo e($panel['key']); ?>][notes]"
                            id="proceed_notes_<?php echo e($panel['key']); ?>"
                            rows="3"
                            class="proceed-step-notes glass-input w-full rounded-xl px-3 py-2 text-sm"
                            placeholder="Masukkan catatan untuk langkah ini (pilihan)..."
                        ><?php echo e(old('proceed_steps.'.$panel['key'].'.notes', $panel['notes'])); ?></textarea>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <p id="proceed-save-status" class="mx-auto mt-4 max-w-2xl hidden text-xs text-slate-500" aria-live="polite"></p>
        </div>
    </div>
</div>
<?php /**PATH D:\project\eSewaan\resources\views/application/partials/proceed-panel.blade.php ENDPATH**/ ?>