<?php
    $activeSteps = $activeSteps ?? ($contract ? \App\Support\AdminProceedSteps::activeStepsFor($contract) : []);
    $totalSteps = count($activeSteps);
    $progressPercent = $totalSteps > 0 ? (int) round(($completedCount / $totalSteps) * 100) : 0;
    $isReadyForHq = $progressPercent >= 100;
    $stepHasError = $errors->has('completed');
    $clientNavigation = $clientNavigation ?? false;
    $readOnly = $readOnly ?? false;
?>
<nav aria-label="Langkah tindakan" class="w-full" id="proceed-stepper">
    <div class="mb-5">
        <div class="mb-2 flex items-center justify-between text-xs">
            <span class="font-medium text-slate-700">Tindakan</span>
            <span id="proceed-progress-count" class="<?php echo e($isReadyForHq ? 'font-semibold text-emerald-700' : 'text-slate-500'); ?>"><?php echo e($progressPercent); ?>%</span>
        </div>
        <div class="h-1.5 overflow-hidden rounded-full glass-progress-track">
            <div
                id="proceed-progress-bar"
                class="h-full rounded-full transition-all duration-300 <?php echo e($isReadyForHq ? 'glass-progress-fill-emerald' : ($progressPercent > 0 ? 'glass-progress-fill-amber' : 'glass-progress-fill')); ?>"
                style="width: <?php echo e($progressPercent); ?>%"
            ></div>
        </div>
        <?php if($isReadyForHq): ?>
            <p id="proceed-ready-status" class="mt-2 text-xs font-medium text-emerald-700">
                Permohonan sedia untuk dihantar ke Ibu Pejabat
            </p>
        <?php else: ?>
            <p id="proceed-ready-status" class="mt-2 hidden text-xs font-medium text-emerald-700"></p>
        <?php endif; ?>
    </div>

    <ol class="space-y-0">
        <?php $__currentLoopData = $activeSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stepNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $displayNumber = $index + 1;
                $definition = \App\Support\AdminProceedSteps::definitionForStep($stepNumber);
                $stepKey = $definition['key'];
                $isCompleted = ($progress[$stepKey]['completed'] ?? false) === true;
                $isCurrent = $stepNumber === $step;
                $isNavigable = ! $readOnly && ($clientNavigation || ($contract && \App\Support\AdminProceedSteps::isNavigable($contract, $stepNumber)));
                $isLast = $index === $totalSteps - 1;
                $isError = $isCurrent && $stepHasError;
            ?>
            <li class="relative flex gap-3" data-step-item="<?php echo e($stepNumber); ?>" data-display-number="<?php echo e($displayNumber); ?>">
                <div class="flex flex-col items-center">
                    <?php if($readOnly): ?>
                        <span
                            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold',
                                'glass-step-active ring-4 ring-blue-200/80' => $isCurrent,
                                'glass-subtle border border-slate-300/50 text-slate-600' => ! $isCurrent,
                            ]); ?>"
                        ><?php echo e($displayNumber); ?></span>
                    <?php elseif($isNavigable): ?>
                        <?php if($clientNavigation): ?>
                            <button
                                type="button"
                                data-proceed-step="<?php echo e($stepNumber); ?>"
                                aria-current="<?php echo e($isCurrent ? 'step' : 'false'); ?>"
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'proceed-step-trigger proceed-step-badge relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
                                    'bg-red-600 text-white ring-4 ring-red-100 focus-visible:ring-red-500' => $isError,
                                    'glass-step-active ring-4 ring-blue-200/80 focus-visible:ring-blue-500' => $isCurrent && ! $isError,
                                    'glass-step-done focus-visible:ring-emerald-500' => $isCompleted && ! $isCurrent,
                                    'glass-step-pending focus-visible:ring-amber-400' => ! $isCompleted && ! $isCurrent,
                                ]); ?>"
                            >
                                <?php if($isCompleted && ! $isCurrent): ?>
                                    <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7" /></svg>
                                <?php else: ?>
                                    <?php echo e($displayNumber); ?>

                                <?php endif; ?>
                            </button>
                        <?php else: ?>
                        <a
                            href="<?php echo e(route($proceedRouteName ?? 'admin-proceed.show', ['contract' => $contract, 'step' => $stepNumber])); ?>"
                            aria-current="<?php echo e($isCurrent ? 'step' : 'false'); ?>"
                            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
                                'bg-red-600 text-white ring-4 ring-red-100 focus-visible:ring-red-500' => $isError,
                                'glass-step-active ring-4 ring-blue-200/80 focus-visible:ring-blue-500' => $isCurrent && ! $isError,
                                'glass-step-done focus-visible:ring-emerald-500' => $isCompleted && ! $isCurrent,
                                'glass-step-pending focus-visible:ring-amber-400' => ! $isCompleted && ! $isCurrent,
                            ]); ?>"
                        >
                            <?php if($isCompleted && ! $isCurrent): ?>
                                <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7" /></svg>
                            <?php else: ?>
                                <?php echo e($displayNumber); ?>

                            <?php endif; ?>
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <span
                            aria-disabled="true"
                            class="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 border-slate-200 bg-slate-50 text-xs font-semibold text-slate-400"
                            title="Lengkapkan langkah sebelumnya terlebih dahulu"
                        ><?php echo e($displayNumber); ?></span>
                    <?php endif; ?>

                    <?php if (! ($isLast)): ?>
                        <div data-step-connector="<?php echo e($stepNumber); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'proceed-step-connector my-1 w-0.5 flex-1 min-h-[1.75rem] rounded-full',
                            $isError ? 'bg-red-300' : ($isCompleted ? 'bg-emerald-300' : 'bg-amber-300'),
                        ]); ?>"></div>
                    <?php endif; ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['min-w-0 flex-1', ! $isLast ? 'pb-5' : 'pb-0']); ?>">
                    <?php if($readOnly): ?>
                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'rounded-xl border px-3.5 py-3',
                            'glass-step-card-active shadow-sm' => $isCurrent,
                            'border-transparent' => ! $isCurrent,
                        ]); ?>">
                            <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'text-[11px] font-medium uppercase tracking-wide',
                                'text-blue-700' => $isCurrent,
                                'text-slate-400' => ! $isCurrent,
                            ]); ?>">
                                <?php if($isCurrent): ?>
                                    Seterusnya
                                <?php else: ?>
                                    Langkah <?php echo e($displayNumber); ?>

                                <?php endif; ?>
                            </p>
                            <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'mt-0.5 text-sm font-medium leading-snug',
                                'text-slate-900' => $isCurrent,
                                'text-slate-600' => ! $isCurrent,
                            ]); ?>"><?php echo e($definition['title']); ?></p>
                        </div>
                    <?php elseif($isNavigable): ?>
                        <?php if($clientNavigation): ?>
                            <button
                                type="button"
                                data-proceed-step="<?php echo e($stepNumber); ?>"
                                aria-current="<?php echo e($isCurrent ? 'step' : 'false'); ?>"
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'proceed-step-trigger proceed-step-card group block w-full rounded-2xl border px-3.5 py-3 text-left transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
                                    'border-red-300 bg-red-50/80 shadow-sm ring-1 ring-red-200 focus-visible:ring-red-500' => $isError,
                                    'glass-step-card-active focus-visible:ring-blue-500' => $isCurrent && ! $isError,
                                    'glass-step-card-pending focus-visible:ring-amber-400' => ! $isCompleted && ! $isCurrent,
                                    'glass-step-card-done focus-visible:ring-emerald-500' => $isCompleted && ! $isCurrent,
                                ]); ?>"
                            >
                        <?php else: ?>
                        <a
                            href="<?php echo e(route($proceedRouteName ?? 'admin-proceed.show', ['contract' => $contract, 'step' => $stepNumber])); ?>"
                            aria-current="<?php echo e($isCurrent ? 'step' : 'false'); ?>"
                            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'group block rounded-2xl border px-3.5 py-3 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
                                'border-red-300 bg-red-50/80 shadow-sm ring-1 ring-red-200 focus-visible:ring-red-500' => $isError,
                                'glass-step-card-active focus-visible:ring-blue-500' => $isCurrent && ! $isError,
                                'glass-step-card-pending focus-visible:ring-amber-400' => ! $isCompleted && ! $isCurrent,
                                'glass-step-card-done focus-visible:ring-emerald-500' => $isCompleted && ! $isCurrent,
                            ]); ?>"
                        >
                        <?php endif; ?>

                            <p data-step-status="<?php echo e($stepNumber); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'text-[11px] font-medium uppercase tracking-wide',
                                'text-red-600' => $isError,
                                'text-blue-700' => $isCurrent && ! $isError,
                                'text-emerald-600' => $isCompleted && ! $isCurrent,
                                'text-amber-600' => ! $isCompleted && ! $isCurrent,
                            ]); ?>">
                                <?php if($isError): ?>
                                    Perlu pengesahan
                                <?php elseif($isCompleted && ! $isCurrent): ?>
                                    Selesai
                                <?php elseif($isCurrent): ?>
                                    Sedang dijalankan
                                <?php elseif(! $isCompleted): ?>
                                    Belum selesai
                                <?php else: ?>
                                    Langkah <?php echo e($displayNumber); ?>

                                <?php endif; ?>
                            </p>
                            <p data-step-title="<?php echo e($stepNumber); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'mt-0.5 text-sm font-medium leading-snug',
                                'text-red-900' => $isError,
                                'text-slate-900' => $isCurrent && ! $isError,
                                'text-emerald-800' => $isCompleted && ! $isCurrent,
                                'text-slate-700 group-hover:text-slate-900' => ! $isCurrent && ! $isCompleted,
                            ]); ?>"><?php echo e($definition['title']); ?></p>

                        <?php if($clientNavigation): ?>
                            </button>
                        <?php else: ?>
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="rounded-xl border border-transparent px-3.5 py-3 opacity-50">
                            <p class="text-[11px] font-medium uppercase tracking-wide text-slate-400">Langkah <?php echo e($displayNumber); ?></p>
                            <p class="mt-0.5 text-sm font-medium leading-snug text-slate-500"><?php echo e($definition['title']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH D:\project\eSewaan\resources\views/partials/admin-proceed-stepper.blade.php ENDPATH**/ ?>