<?php
    $sort = $sort ?? 'created_at';
    $direction = $direction ?? 'desc';
    $canManageUserStatus = $canManageUserStatus ?? false;
    $showAdminSection = $showAdminSection ?? false;
    $adminUsers = $adminUsers ?? collect();
    $negeriUsers = $negeriUsers ?? collect();
    $totalUsers = $adminUsers->count() + $negeriUsers->count();
?>
<p id="users-count" class="text-sm text-slate-600">
    Menunjukkan <strong class="text-slate-800"><?php echo e($totalUsers); ?></strong> pengguna
    <?php if($showAdminSection): ?>
        (<strong class="text-slate-800"><?php echo e($adminUsers->count()); ?></strong> Ibu Pejabat,
        <strong class="text-slate-800"><?php echo e($negeriUsers->count()); ?></strong> Negeri)
    <?php endif; ?>
</p>

<?php if($showAdminSection): ?>
<section class="glass-card glass-table overflow-hidden">
    <div class="glass-divider-soft border-b px-4 py-3">
        <h2 class="text-base font-semibold text-slate-900">Ibu Pejabat</h2>
        <p class="mt-0.5 text-xs text-slate-500">Pengguna peranan Ibu Pejabat.</p>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="glass-divider-soft border-b bg-white/40">
                    <?php $__currentLoopData = [
                        'name' => 'Nama',
                        'email' => 'Emel',
                        'is_active' => 'Status',
                        'created_at' => 'Didaftar',
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-gray-500 <?php echo e($column === 'is_active' ? 'text-center' : 'text-left'); ?>">
                        <button
                            type="button"
                            data-users-sort="<?php echo e($column); ?>"
                            class="group inline-flex items-center gap-1 hover:text-slate-800 <?php echo e($sort === $column ? 'text-slate-800' : ''); ?> <?php echo e($column === 'is_active' ? 'mx-auto' : ''); ?>"
                        >
                            <span><?php echo e($label); ?></span>
                            <span class="text-[10px] leading-none opacity-70">
                                <?php if($sort === $column): ?>
                                    <?php echo e($direction === 'asc' ? '▲' : '▼'); ?>

                                <?php else: ?>
                                    <span class="text-gray-300 group-hover:text-slate-400">↕</span>
                                <?php endif; ?>
                            </span>
                        </button>
                    </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-500">Tindakan</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $adminUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('users.partials.row', [
                        'user' => $user,
                        'canManageUserStatus' => $canManageUserStatus,
                        'showNegeriColumn' => false,
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-4 py-10 text-center text-slate-500">
                        Tiada pengguna Ibu Pejabat dijumpai.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php endif; ?>

<section class="glass-card glass-table overflow-hidden">
    <div class="glass-divider-soft border-b px-4 py-3">
        <h2 class="text-base font-semibold text-slate-900">Negeri</h2>
        <p class="mt-0.5 text-xs text-slate-500">Pengguna peranan Negeri.</p>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="glass-divider-soft border-b bg-white/40">
                    <?php $__currentLoopData = [
                        'name' => 'Nama',
                        'email' => 'Emel',
                        'negeri' => 'Negeri',
                        'is_active' => 'Status',
                        'created_at' => 'Didaftar',
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-gray-500 <?php echo e($column === 'is_active' ? 'text-center' : 'text-left'); ?>">
                        <button
                            type="button"
                            data-users-sort="<?php echo e($column); ?>"
                            class="group inline-flex items-center gap-1 hover:text-slate-800 <?php echo e($sort === $column ? 'text-slate-800' : ''); ?> <?php echo e($column === 'is_active' ? 'mx-auto' : ''); ?>"
                        >
                            <span><?php echo e($label); ?></span>
                            <span class="text-[10px] leading-none opacity-70">
                                <?php if($sort === $column): ?>
                                    <?php echo e($direction === 'asc' ? '▲' : '▼'); ?>

                                <?php else: ?>
                                    <span class="text-gray-300 group-hover:text-slate-400">↕</span>
                                <?php endif; ?>
                            </span>
                        </button>
                    </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-500">Tindakan</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $negeriUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('users.partials.row', [
                        'user' => $user,
                        'canManageUserStatus' => $canManageUserStatus,
                        'showNegeriColumn' => true,
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-4 py-10 text-center text-slate-500">
                        Tiada pengguna Negeri dijumpai.
                        <?php if(empty($search)): ?>
                        <a href="<?php echo e(route('users.create')); ?>" class="mt-2 block glass-link">Daftar pengguna pertama</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php /**PATH D:\project\eSewaan\resources\views/users/partials/table.blade.php ENDPATH**/ ?>