
<?php
    $maxKilobytes = $maxKilobytes ?? \App\Support\UploadLimits::effectiveMaxKilobytes();
    $maxBytes = $maxKilobytes * 1024;
    $humanLimit = $humanLimit ?? \App\Support\UploadLimits::humanEffectiveLimit();
    $inputId = $inputId ?? 'document';
    $errorId = $errorId ?? $inputId.'-size-error';
    $formId = $formId ?? null;
?>

<p id="<?php echo e($errorId); ?>" class="mt-1 hidden text-xs font-medium text-red-600" role="alert" aria-live="polite"></p>

<script>
(function () {
    const input = document.getElementById(<?php echo json_encode($inputId, 15, 512) ?>);
    const errorEl = document.getElementById(<?php echo json_encode($errorId, 15, 512) ?>);
    const maxBytes = <?php echo e((int) $maxBytes); ?>;
    const humanLimit = <?php echo json_encode($humanLimit, 15, 512) ?>;
    const form = <?php echo json_encode($formId, 15, 512) ?> ? document.getElementById(<?php echo json_encode($formId, 15, 512) ?>) : input?.closest('form');

    if (! input || ! errorEl) {
        return;
    }

    function clearError() {
        errorEl.textContent = '';
        errorEl.classList.add('hidden');
        input.setCustomValidity('');
    }

    function showError(message) {
        errorEl.textContent = message;
        errorEl.classList.remove('hidden');
        input.setCustomValidity(message);
    }

    function validateSelectedFile() {
        clearError();

        const file = input.files?.[0];
        if (! file) {
            return true;
        }

        if (file.size > maxBytes) {
            const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
            showError('Fail terlalu besar (' + sizeMb + 'MB). Had maksimum ialah ' + humanLimit + '. Sila pilih fail yang lebih kecil.');
            input.value = '';
            return false;
        }

        return true;
    }

    input.addEventListener('change', validateSelectedFile);

    form?.addEventListener('submit', function (event) {
        if (! validateSelectedFile()) {
            event.preventDefault();
            event.stopImmediatePropagation();
            input.focus();
        }
    }, true);
})();
</script>
<?php /**PATH D:\project\eSewaan\resources\views/partials/file-size-guard.blade.php ENDPATH**/ ?>