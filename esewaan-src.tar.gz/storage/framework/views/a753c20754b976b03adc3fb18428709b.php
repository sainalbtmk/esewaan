<?php
    $draftDocuments = $contract->documents
        ->where('jenis', \App\Models\ContractDocument::JENIS_DRAF_PERJANJIAN)
        ->sortByDesc('semakan_round');
    $puuAmendments = $contract->documents
        ->where('jenis', \App\Models\ContractDocument::JENIS_PINDAAN_PUU)
        ->keyBy(fn ($document) => (int) $document->semakan_round);
    $approvedDocuments = $contract->documents
        ->where('jenis', \App\Models\ContractDocument::JENIS_LULUS_PUU)
        ->keyBy(fn ($document) => (int) $document->semakan_round);
?>

<?php if($draftDocuments->isNotEmpty()): ?>
    <div>
        <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Sejarah Muat Naik Draf</p>
        <ul class="mt-2 space-y-2">
            <?php $__currentLoopData = $draftDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex flex-col gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="shrink-0 font-medium text-indigo-700"><?php echo e($document->semakanLabel() ?? 'Draf Perjanjian'); ?></span>
                        <span class="<?php echo e($document->semakanStatusBadgeClass()); ?> text-[11px]">
                            <?php echo e($document->semakanStatusLabel()); ?>

                        </span>
                    </div>
                    <div class="flex min-w-0 flex-col gap-1 sm:items-end">
                        <a
                            href="<?php echo e($document->downloadUrl()); ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="truncate text-slate-600 underline-offset-2 hover:text-indigo-600 hover:underline"
                        >
                            <?php echo e($document->nama_fail); ?>

                        </a>
                        <?php if($amendment = $puuAmendments->get((int) $document->semakan_round)): ?>
                            <a
                                href="<?php echo e($amendment->downloadUrl()); ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="truncate text-xs text-amber-800 underline-offset-2 hover:underline"
                            >
                                Dokumen pindaan PUU: <?php echo e($amendment->nama_fail); ?>

                            </a>
                        <?php endif; ?>
                        <?php if($approved = $approvedDocuments->get((int) $document->semakan_round)): ?>
                            <a
                                href="<?php echo e($approved->downloadUrl()); ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="truncate text-xs text-emerald-800 underline-offset-2 hover:underline"
                            >
                                Dokumen lulus PUU: <?php echo e($approved->nama_fail); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\project\eSewaan\resources\views/status-permohonan/partials/draft-document-history.blade.php ENDPATH**/ ?>