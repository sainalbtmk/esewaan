<?php $__env->startSection('title', 'Pendaftaran Pengguna'); ?>
<?php $__env->startSection('header_title', 'Pendaftaran Pengguna'); ?>
<?php $__env->startSection('header_subtitle', 'Pengurusan Pengguna — cipta akaun pengguna baharu'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $defaultRole = old('role', auth()->user()->isAdminNegeri() ? 'admin_negeri' : 'admin_hq');
    $showNegeriField = ($lockNegeri ?? false) || $defaultRole === 'admin_negeri';
?>
<div class="flex min-h-[calc(100vh-7rem)] items-center justify-center lg:min-h-[calc(100vh-8rem)]">
    <div class="glass-card w-full max-w-md p-8">
        <h1 class="mb-6 text-2xl font-bold text-slate-800">Pendaftaran Pengguna</h1>
        <form method="POST" action="<?php echo e(route('users.store')); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>
            <div>
                <label for="name" class="mb-1 block text-sm font-medium text-slate-700">Nama</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required autofocus
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
            </div>
            <div>
                <label for="email" class="mb-1 block text-sm font-medium text-slate-700">Emel</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
            </div>
            <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Kata laluan','name' => 'password','inputId' => 'register-password','autocomplete' => 'new-password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Kata laluan','name' => 'password','input-id' => 'register-password','autocomplete' => 'new-password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Sahkan kata laluan','name' => 'password_confirmation','inputId' => 'register-password-confirm','autocomplete' => 'new-password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sahkan kata laluan','name' => 'password_confirmation','input-id' => 'register-password-confirm','autocomplete' => 'new-password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
            <div>
                <label for="role" class="mb-1 block text-sm font-medium text-slate-700">Peranan</label>
                <select name="role" id="role" required class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                    <?php if(! auth()->user()->isAdminNegeri()): ?>
                    <option value="admin_hq" <?php if($defaultRole === 'admin_hq'): echo 'selected'; endif; ?>>Ibu Pejabat</option>
                    <?php endif; ?>
                    <option value="admin_negeri" <?php if($defaultRole === 'admin_negeri'): echo 'selected'; endif; ?>>Negeri</option>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div id="negeri-field" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hidden' => ! $showNegeriField]); ?>">
                <label for="negeri" class="mb-1 block text-sm font-medium text-slate-700">Negeri</label>
                <?php if($lockNegeri ?? false): ?>
                <input type="hidden" name="negeri" value="<?php echo e($lockedNegeri); ?>">
                <p class="glass-field-static px-3 py-2 text-sm text-slate-700"><?php echo e($lockedNegeri); ?></p>
                <p class="mt-1 text-xs text-slate-500">Negeri dikunci mengikut negeri pentadbir anda.</p>
                <?php else: ?>
                <select name="negeri" id="negeri"
                    <?php if($showNegeriField): echo 'required'; endif; ?>
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                    <option value="">- Pilih Negeri -</option>
                    <?php $__currentLoopData = $negeriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(old('negeri') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php endif; ?>
                <?php $__errorArgs = ['negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="glass-btn-primary w-full rounded-xl px-4 py-2.5 font-medium">
                Daftar pengguna
            </button>
        </form>
    </div>
</div>
<?php echo $__env->make('partials.auth-password-toggle-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if(! ($lockNegeri ?? false)): ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const roleSelect = document.getElementById('role');
    const negeriField = document.getElementById('negeri-field');
    const negeriSelect = document.getElementById('negeri');

    if (!roleSelect || !negeriField || !negeriSelect) {
        return;
    }

    function syncNegeriVisibility() {
        const needsNegeri = roleSelect.value === 'admin_negeri';
        negeriField.classList.toggle('hidden', !needsNegeri);
        negeriSelect.required = needsNegeri;

        if (!needsNegeri) {
            negeriSelect.value = '';
        }
    }

    roleSelect.addEventListener('change', syncNegeriVisibility);
    syncNegeriVisibility();
})();
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/auth/register.blade.php ENDPATH**/ ?>