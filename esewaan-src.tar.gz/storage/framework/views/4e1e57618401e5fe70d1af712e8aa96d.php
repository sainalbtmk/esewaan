<?php $__env->startSection('title', 'Peti Masuk'); ?>
<?php $__env->startSection('header_title', 'Peti Masuk'); ?>
<?php $__env->startSection('header_subtitle', 'Notifikasi kemajuan permohonan, status dan kontrak'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <p class="text-sm text-slate-600">
            Menunjukkan
            <strong class="text-slate-800"><?php echo e($items->count()); ?></strong>
            notifikasi belum dibaca
            <?php if($inboxTotal > 0): ?>
                · jumlah badge: <strong class="text-slate-800"><?php echo e($inboxTotal); ?></strong>
            <?php endif; ?>
        </p>

        <?php if($items->isNotEmpty()): ?>
            <form method="POST" action="<?php echo e(route('notifications.mark-all-read')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="glass-btn-secondary rounded-lg px-4 py-2 text-sm font-medium">
                    Tanda semua sebagai dibaca
                </button>
            </form>
        <?php endif; ?>
    </div>

    <section class="glass-card overflow-hidden">
        <div class="divide-y divide-slate-100">
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a
                    href="<?php echo e($item['url']); ?>"
                    class="block px-4 py-3 transition-colors hover:bg-slate-50/80"
                >
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                                <?php echo e($item['category_label']); ?>

                            </p>
                            <p class="mt-0.5 text-sm font-semibold text-slate-900"><?php echo e($item['title']); ?></p>
                            <p class="mt-0.5 text-sm text-slate-600"><?php echo e($item['message']); ?></p>
                        </div>
                        <time class="shrink-0 text-xs text-slate-400" datetime="<?php echo e($item['occurred_at']?->toIso8601String()); ?>">
                            <?php echo e($item['occurred_at']?->format('d/m/Y H:i') ?? '–'); ?>

                        </time>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-4 py-12 text-center text-sm text-slate-500">
                    Tiada notifikasi baharu buat masa ini.
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/notifications/index.blade.php ENDPATH**/ ?>