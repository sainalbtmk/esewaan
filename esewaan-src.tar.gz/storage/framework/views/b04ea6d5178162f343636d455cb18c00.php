<?php
    $search = $search ?? '';
?>
<p id="status-permohonan-count" class="text-sm text-slate-600">
    Menunjukkan <strong class="text-slate-800"><?php echo e($contracts->count()); ?></strong> daripada <strong class="text-slate-800"><?php echo e($contracts->total()); ?></strong> permohonan dipadam
</p>

<div class="glass-card glass-table overflow-hidden">
    <div class="overflow-x-auto">
    <table class="w-full min-w-[52rem] text-sm">
        <thead>
            <tr class="glass-divider border-b">
                <th class="min-w-[12rem] px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Nama Premis</th>
                <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Kategori</th>
                <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Negeri</th>
                <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Status Semasa Dipadam</th>
                <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Dipadam Oleh</th>
                <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Tarikh Padam</th>
                <th class="min-w-[14rem] px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Alasan Padam</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $namaPtj = $c->displayNamaPtj();
                ?>
                <tr class="glass-row-neutral">
                    <td class="min-w-[12rem] px-4 py-3.5 text-sm text-slate-800">
                        <p class="font-medium text-slate-800" title="<?php echo e($namaPtj); ?>"><?php echo e($namaPtj); ?></p>
                    </td>
                    <td class="px-4 py-3 text-sm text-slate-600">
                        <?php echo e(\App\Support\ApplicationCategories::label($c->kategori_permohonan)); ?>

                    </td>
                    <td class="px-4 py-3 text-sm text-slate-600"><?php echo e($c->premise?->negeri ?? '–'); ?></td>
                    <td class="px-4 py-3 text-sm text-slate-600"><?php echo e($c->workflowLabel()); ?></td>
                    <td class="px-4 py-3 text-sm text-slate-600">
                        <div>
                            <p class="font-medium text-slate-800"><?php echo e($c->deletedBy?->name ?? '–'); ?></p>
                            <?php if($c->deletedBy?->negeri): ?>
                                <p class="text-xs text-slate-500"><?php echo e($c->deletedBy->negeri); ?></p>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td class="px-4 py-3 text-sm text-slate-600">
                        <?php echo e($c->deleted_at?->format('d/m/Y H:i') ?? '–'); ?>

                    </td>
                    <td class="min-w-[14rem] px-4 py-3 text-sm text-slate-700">
                        <p class="whitespace-pre-wrap leading-relaxed"><?php echo e($c->delete_reason ?? '–'); ?></p>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-4 py-12 text-center text-slate-500">
                        Tiada rekod sejarah permohonan dipadam.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<div id="status-permohonan-pagination" class="mt-4">
    <?php echo e($contracts->withQueryString()->links()); ?>

</div>
<?php /**PATH D:\project\eSewaan\resources\views/status-permohonan/partials/history-table.blade.php ENDPATH**/ ?>