<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: sans-serif; line-height: 1.5; }
        table { border-collapse: collapse; width: 100%; max-width: 640px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: top; }
        th { background: #f4f4f4; width: 35%; }
        .cta { margin-top: 20px; }
        .cta a { display: inline-block; padding: 10px 16px; background: #1d4ed8; color: #fff !important; text-decoration: none; border-radius: 6px; }
    </style>
</head>
<body>
    <h2><?php echo e($payload['heading']); ?></h2>
    <p><?php echo e($payload['intro']); ?></p>

    <table>
        <tr>
            <th>Nama Premis</th>
            <td><?php echo e($contract->premise?->nama_ptj ?? '—'); ?></td>
        </tr>
        <tr>
            <th>Negeri</th>
            <td><?php echo e($contract->premise?->negeri ?? '—'); ?></td>
        </tr>
        <tr>
            <th>Nama Pemohon</th>
            <td><?php echo e($contract->displayAdminNegeriName()); ?></td>
        </tr>
        <tr>
            <th>Kategori Permohonan</th>
            <td><?php echo e(\App\Support\ApplicationCategories::label($contract->kategori_permohonan)); ?></td>
        </tr>
        <tr>
            <th>Tindakan oleh</th>
            <td><?php echo e($actedBy->name); ?></td>
        </tr>
        <tr>
            <th>Peringkat Stepper</th>
            <td><?php echo e($payload['next_status']); ?></td>
        </tr>
    </table>

    <p class="cta">
        <a href="<?php echo e($payload['cta_url']); ?>"><?php echo e($payload['cta_label']); ?></a>
    </p>

    <p>Ini adalah notifikasi automatik daripada SPEKTRA.</p>
</body>
</html>
<?php /**PATH D:\project\eSewaan\resources\views/emails/application-workflow-stage.blade.php ENDPATH**/ ?>