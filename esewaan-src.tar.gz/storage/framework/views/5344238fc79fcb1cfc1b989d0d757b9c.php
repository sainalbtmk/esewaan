<?php
    use App\Support\HqDraftAcknowledgements;

    $savedAcknowledgements = is_array($contract->hq_draft_acknowledgements)
        ? $contract->hq_draft_acknowledgements
        : [];
    $acknowledgementsCompleted = $acknowledgementsCompleted ?? false;
?>

<div class="space-y-3">
    <?php $__currentLoopData = HqDraftAcknowledgements::labels(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acknowledgementKey => $acknowledgementLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $isChecked = array_key_exists($acknowledgementKey, $savedAcknowledgements)
                ? filter_var($savedAcknowledgements[$acknowledgementKey], FILTER_VALIDATE_BOOLEAN)
                : $acknowledgementsCompleted;
            $acknowledgementDate = HqDraftAcknowledgements::dateFor($savedAcknowledgements, $acknowledgementKey);
        ?>
        <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <label class="flex min-w-0 items-start gap-3 text-sm text-slate-700">
                <input
                    type="checkbox"
                    disabled
                    <?php if($isChecked): echo 'checked'; endif; ?>
                    class="mt-0.5 h-4 w-4 shrink-0 cursor-default rounded border-slate-300 text-emerald-600"
                >
                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'text-slate-800' => $isChecked,
                    'text-slate-500' => ! $isChecked,
                ]); ?>"><?php echo e($acknowledgementLabel); ?></span>
            </label>
            <?php if($isChecked): ?>
                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'ml-7 shrink-0 text-sm sm:ml-0',
                    'font-medium text-slate-800' => filled($acknowledgementDate),
                    'text-slate-500' => ! filled($acknowledgementDate),
                ]); ?>">
                    <?php echo e(filled($acknowledgementDate) ? \Carbon\Carbon::parse($acknowledgementDate)->format('d/m/Y') : 'Tiada tarikh'); ?>

                </span>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\project\eSewaan\resources\views/status-permohonan/partials/hq-draft-acknowledgements-readonly.blade.php ENDPATH**/ ?>