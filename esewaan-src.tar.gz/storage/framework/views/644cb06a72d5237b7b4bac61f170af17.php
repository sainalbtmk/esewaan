<?php
    use App\Support\ContractNegeriReport;
    use App\Support\RentalStatusReport;
?>

<?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <h2 class="section-bar"><?php echo e(mb_strtoupper($group['title'], 'UTF-8')); ?> (<?php echo e(number_format($group['rows']->count())); ?>)</h2>
    <table class="data wide">
        <thead>
            <tr>
                <th>No</th>
                <th>Negeri</th>
                <th>Daerah</th>
                <th>PTJ</th>
                <th>Alamat</th>
                <th>Mula</th>
                <th>Tamat</th>
                <th>Baki Bulan</th>
                <th>Kadar Sewa</th>
                <th>Kategori</th>
                <th>Status</th>
                <th>Rumusan Status Terkini</th>
                <th>Tindakan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $group['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $bakiBulan = RentalStatusReport::bakiBulan($contract);
                    $diterima = (bool) ($contract->laporan_status_diterima ?? false);
                ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($contract->premise?->negeri ?? '–'); ?></td>
                    <td><?php echo e($contract->premise?->daerah ?: '–'); ?></td>
                    <td><?php echo e($contract->premise?->nama_ptj ?? '–'); ?></td>
                    <td class="pre"><?php echo e($contract->premise?->alamat_penuh ?: '–'); ?></td>
                    <td><?php echo e(ContractNegeriReport::mula($contract)); ?></td>
                    <td><?php echo e(ContractNegeriReport::tamat($contract)); ?></td>
                    <td class="<?php echo e(RentalStatusReport::isBakiBulanKritikal($contract) ? 'baki-negatif' : ''); ?>"><?php echo e($bakiBulan === null ? '–' : number_format($bakiBulan)); ?></td>
                    <td><?php echo e(ContractNegeriReport::kadarSewa($contract)); ?></td>
                    <td class="kategori"><?php echo e(RentalStatusReport::kategoriLabel($contract)); ?></td>
                    <td class="<?php echo e($diterima ? 'status-terima' : 'status-belum'); ?>"><?php echo e($diterima ? 'Terima' : 'Belum Terima'); ?></td>
                    <td><?php echo e($contract->laporan_status_rumusan ?? '–'); ?></td>
                    <td><?php echo e($contract->laporan_status_tindakan ?? '–'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="muted">Tiada rekod untuk laporan ini.</p>
<?php endif; ?>
<?php /**PATH D:\project\eSewaan\resources\views/reports/partials/status-sewaan-pdf-table.blade.php ENDPATH**/ ?>