<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: sans-serif; color: #0f172a; }
        table { border-collapse: collapse; width: 100%; margin: 16px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #f4f4f4; }
        .muted { color: #64748b; font-size: 13px; }
        .warning { color: #991b1b; }
    </style>
</head>
<body>
    <h2 <?php if($tier === \App\Support\ContractExpiryReminderTier::ThreeMonth): ?> style="color: #991b1b;" <?php endif; ?>><?php echo e($tier->heading()); ?></h2>
    <p><?php echo e($tier->intro()); ?></p>
    <table>
        <thead>
            <tr>
                <th>Nama Premis</th>
                <th>Negeri</th>
                <th>Tarikh Tamat</th>
                <th>Baki Tempoh</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contract->premise?->nama_ptj ?? '–'); ?></td>
                    <td><?php echo e($contract->premise?->negeri ?? '–'); ?></td>
                    <td><?php echo e($contract->contractEndDate()?->format('d/m/Y') ?? '–'); ?></td>
                    <td><?php echo e($contract->daysUntilContractEndLabel()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <p>
        <a href="<?php echo e(route('kontrak-sewaan.index')); ?>">Buka Senarai Kontrak Sewaan</a>
    </p>
    <p class="muted"><?php echo e($tier->footnote()); ?></p>
    <p class="muted">Ini adalah notifikasi automatik daripada SPEKTRA.</p>
</body>
</html>
<?php /**PATH D:\project\eSewaan\resources\views/emails/contract-expiry-reminder.blade.php ENDPATH**/ ?>