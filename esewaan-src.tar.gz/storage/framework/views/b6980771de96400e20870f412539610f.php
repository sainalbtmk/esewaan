<?php $__env->startSection('title', 'Urus Profil Pengguna'); ?>
<?php $__env->startSection('header_title', 'Urus Profil Pengguna'); ?>
<?php $__env->startSection('header_subtitle', $user->name); ?>

<?php $__env->startSection('content'); ?>
<?php
    $selectedRole = old('role', $user->role);
    $showNegeriField = ($lockNegeri ?? false) || $selectedRole === 'admin_negeri';
?>
<div class="mx-auto max-w-2xl space-y-6">
    <div class="glass-card p-6">
        <h1 class="mb-6 text-xl font-bold text-slate-800">Kemaskini profil</h1>
        <form method="POST" action="<?php echo e(route('users.update', $user)); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label for="name" class="mb-1 block text-sm font-medium text-slate-700">Nama penuh</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" required
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
            </div>
            <div>
                <label for="email" class="mb-1 block text-sm font-medium text-slate-700">Emel</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" required
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
            </div>
            <div>
                <label for="role" class="mb-1 block text-sm font-medium text-slate-700">Peranan</label>
                <?php if($user->is(auth()->user())): ?>
                <p class="glass-field-static px-3 py-2 text-sm text-slate-700"><?php echo e($user->roleLabel()); ?></p>
                <p class="mt-1 text-xs text-slate-500">Anda tidak boleh menukar peranan sendiri.</p>
                <input type="hidden" id="role" value="<?php echo e($user->role); ?>">
                <?php else: ?>
                <select name="role" id="role" required
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                    <option value="admin_negeri" <?php if($selectedRole === 'admin_negeri'): echo 'selected'; endif; ?>>Negeri</option>
                    <?php if(! auth()->user()->isAdminNegeri()): ?>
                    <option value="admin_hq" <?php if($selectedRole === 'admin_hq'): echo 'selected'; endif; ?>>Ibu Pejabat</option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
            </div>
            <div id="negeri-field" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hidden' => ! $showNegeriField]); ?>">
                <label for="negeri" class="mb-1 block text-sm font-medium text-slate-700">Negeri</label>
                <?php if($lockNegeri ?? false): ?>
                <input type="hidden" name="negeri" value="<?php echo e($lockedNegeri); ?>">
                <p class="glass-field-static px-3 py-2 text-sm text-slate-700"><?php echo e($lockedNegeri); ?></p>
                <p class="mt-1 text-xs text-slate-500">Negeri dikunci mengikut negeri pentadbir anda.</p>
                <?php else: ?>
                <select name="negeri" id="negeri"
                    <?php if($showNegeriField): echo 'required'; endif; ?>
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                    <option value="">— Pilih negeri —</option>
                    <?php $__currentLoopData = $negeriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(old('negeri', $user->negeri) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php endif; ?>
                <?php $__errorArgs = ['negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="rounded-lg border border-amber-200 bg-amber-50 p-4">
                <p class="mb-3 text-sm font-medium text-amber-900">Reset kata laluan</p>
                <p class="mb-4 text-xs text-amber-800">Biarkan kosong jika tidak mahu menukar kata laluan.</p>
                <div class="space-y-4">
                    <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Kata laluan baharu','name' => 'password','inputId' => 'admin-reset-password','autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Kata laluan baharu','name' => 'password','input-id' => 'admin-reset-password','autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Sahkan kata laluan baharu','name' => 'password_confirmation','inputId' => 'admin-reset-password-confirm','autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sahkan kata laluan baharu','name' => 'password_confirmation','input-id' => 'admin-reset-password-confirm','autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="flex flex-wrap gap-3 pt-2">
                <button type="submit" class="glass-btn-primary rounded-xl px-4 py-2.5 text-sm font-medium">
                    Simpan perubahan
                </button>
                <a href="<?php echo e(route('users.index')); ?>" class="glass-btn-secondary rounded-xl px-4 py-2.5 text-sm font-medium">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>
<?php echo $__env->make('partials.auth-password-toggle-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if(! ($lockNegeri ?? false) && ! $user->is(auth()->user())): ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const roleSelect = document.getElementById('role');
    const negeriField = document.getElementById('negeri-field');
    const negeriSelect = document.getElementById('negeri');

    if (!roleSelect || !negeriField || !negeriSelect) {
        return;
    }

    function syncNegeriVisibility() {
        const needsNegeri = roleSelect.value === 'admin_negeri';
        negeriField.classList.toggle('hidden', !needsNegeri);
        negeriSelect.required = needsNegeri;

        if (!needsNegeri) {
            negeriSelect.value = '';
        }
    }

    roleSelect.addEventListener('change', syncNegeriVisibility);
    syncNegeriVisibility();
})();
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/users/edit.blade.php ENDPATH**/ ?>