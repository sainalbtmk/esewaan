<?php
    $parent = $contract->parentContract;
    $parentPremise = $parent?->premise;
    $newPremise = $contract->premise;
    $parentRent = $parentPremise?->kadar_sewa ?? $parent?->kadar_sewa_bulanan;
    $newRent = $newPremise?->kadar_sewa ?? $contract->kadar_sewa_bulanan;
    $band = $contract->rentDifferenceBand();
    $difference = $contract->rentDifferenceFromParent();
?>

<?php if($parent): ?>
    <div class="glass-panel-muted p-5">
        <div class="mb-4 flex flex-wrap items-center gap-2">
            <span class="rounded-full bg-slate-800 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white">
                Perbandingan <?php echo e(\App\Support\ApplicationCategories::label($contract->kategori_permohonan)); ?>

            </span>
            <?php if($band): ?>
                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'rounded-full px-3 py-1 text-xs font-semibold',
                    'bg-emerald-100 text-emerald-700' => $band === 'below',
                    'bg-amber-100 text-amber-700' => $band === 'above',
                ]); ?>">
                    <?php echo e($contract->rentDifferenceBandLabel()); ?>

                    <?php if($difference !== null): ?>
                        (<?php echo e($difference >= 0 ? '+' : '−'); ?>RM<?php echo e(number_format(abs($difference), 2)); ?>)
                    <?php endif; ?>
                </span>
            <?php endif; ?>
        </div>

        <div class="overflow-hidden rounded-xl border border-white/70 bg-white/60">
            <table class="w-full text-sm">
                <thead>
                    <tr class="glass-divider border-b text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                        <th class="px-4 py-2.5">Maklumat</th>
                        <th class="px-4 py-2.5">Kontrak Lama</th>
                        <th class="px-4 py-2.5">Permohonan Baharu</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <tr>
                        <td class="px-4 py-2.5 font-medium text-slate-600">Nama Premis</td>
                        <td class="px-4 py-2.5 text-slate-700"><?php echo e($parentPremise?->nama_ptj ?? '–'); ?></td>
                        <td class="px-4 py-2.5 text-slate-900"><?php echo e($newPremise?->nama_ptj ?? '–'); ?></td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2.5 font-medium text-slate-600">Kadar Sewa (RM)</td>
                        <td class="px-4 py-2.5 text-slate-700"><?php echo e($parentRent !== null ? number_format((float) $parentRent, 2) : '–'); ?></td>
                        <td class="px-4 py-2.5 font-semibold text-slate-900"><?php echo e($newRent !== null ? number_format((float) $newRent, 2) : '–'); ?></td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2.5 font-medium text-slate-600">Tarikh Mula</td>
                        <td class="px-4 py-2.5 text-slate-700"><?php echo e($parent?->tarikh_mula_tawaran?->format('d/m/Y') ?? '–'); ?></td>
                        <td class="px-4 py-2.5 text-slate-900"><?php echo e($contract->tarikh_mula_tawaran?->format('d/m/Y') ?? '–'); ?></td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2.5 font-medium text-slate-600">Tarikh Akhir Tempoh Tawaran Penyewaan</td>
                        <td class="px-4 py-2.5 text-slate-700"><?php echo e($parent?->sah_sehingga?->format('d/m/Y') ?? '–'); ?></td>
                        <td class="px-4 py-2.5 text-slate-900"><?php echo e($contract->sah_sehingga?->format('d/m/Y') ?? '–'); ?></td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2.5 font-medium text-slate-600">Alamat Premis</td>
                        <td class="whitespace-pre-wrap px-4 py-2.5 text-slate-700"><?php echo e($parentPremise?->alamat_penuh ?? '–'); ?></td>
                        <td class="whitespace-pre-wrap px-4 py-2.5 text-slate-900"><?php echo e($newPremise?->alamat_penuh ?? '–'); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <?php if(filled($contract->remark)): ?>
            <div class="mt-4">
                <?php echo $__env->make('partials.readonly-field', ['label' => 'Remark', 'value' => $contract->remark, 'multiline' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\project\eSewaan\resources\views/partials/follow-up-comparison.blade.php ENDPATH**/ ?>