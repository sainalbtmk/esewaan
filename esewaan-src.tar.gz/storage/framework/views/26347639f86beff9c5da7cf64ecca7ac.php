<?php $__env->startSection('title', 'Sediakan pengesahan dua faktor'); ?>
<?php $__env->startSection('header_title', 'Pengesahan dua faktor'); ?>
<?php $__env->startSection('header_subtitle', 'Wajib sebelum menggunakan sistem'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-2xl space-y-6">
    <div class="glass-card p-6">
        <h1 class="text-xl font-bold text-slate-800">Sediakan pengesahan dua faktor</h1>
        <p class="mt-2 text-sm text-slate-600">Tambah akaun ini dalam aplikasi authenticator menggunakan kunci di bawah, kemudian masukkan kod 6 digit untuk mengesahkan.</p>

        <p class="mt-5 text-xs font-semibold uppercase tracking-wide text-slate-500">Kunci persediaan</p>
        <p class="mt-1 break-all font-mono text-sm text-slate-900"><?php echo e(trim(chunk_split($secret, 4, ' '))); ?></p>
        <p class="mt-3 break-all text-xs text-slate-500"><?php echo e($provisioningUri); ?></p>

        <?php if($recoveryCodes !== []): ?>
            <p class="mt-6 text-xs font-semibold uppercase tracking-wide text-slate-500">Kod pemulihan</p>
            <p class="mt-1 text-sm text-slate-600">Simpan kod ini di tempat selamat. Setiap kod hanya boleh digunakan sekali.</p>
            <ul class="mt-3 grid gap-2 sm:grid-cols-2">
                <?php $__currentLoopData = $recoveryCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recoveryCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="rounded-lg bg-slate-50 px-3 py-2 font-mono text-sm text-slate-800"><?php echo e($recoveryCode); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('two-factor.confirm')); ?>" class="mt-6 space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label for="code" class="mb-1 block text-sm font-medium text-slate-700">Kod pengesahan</label>
                <input type="text" name="code" id="code" inputmode="numeric" autocomplete="one-time-code" required class="glass-input w-full rounded-xl px-3 py-2 text-sm tracking-widest">
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="glass-btn-primary rounded-xl px-4 py-2.5 text-sm font-medium">Sahkan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/auth/two-factor-setup.blade.php ENDPATH**/ ?>