<?php $__env->startSection('title', 'Jana Laporan'); ?>
<?php $__env->startSection('header_title', 'Jana Laporan'); ?>
<?php $__env->startSection('header_subtitle', 'Laporan ringkasan permohonan dan kontrak sewaan untuk Ibu Pejabat'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $summary = $report['summary'];
    $rows = $report['rows'];
?>

<div class="space-y-6">
    <form method="GET" action="<?php echo e(route('reports.index')); ?>" class="glass-card p-4 lg:p-5">
        <div class="grid grid-cols-1 gap-4 lg:grid-cols-12 lg:items-end">
            <div class="lg:col-span-3">
                <label for="jenis" class="mb-1 block text-sm font-medium text-slate-700">Jenis Laporan</label>
                <select name="jenis" id="jenis" class="glass-input w-full rounded-xl px-3 py-2.5 text-sm">
                    <?php $__currentLoopData = $jenisList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(($filters['jenis'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="lg:col-span-3">
                <label for="negeri" class="mb-1 block text-sm font-medium text-slate-700">Negeri</label>
                <select name="negeri" id="negeri" class="glass-input w-full rounded-xl px-3 py-2.5 text-sm">
                    <option value="">Semua negeri</option>
                    <?php $__currentLoopData = $negeriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(($filters['negeri'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p class="mt-1 text-xs text-slate-500">Pilih negeri dahulu untuk tapis sehingga daerah.</p>
            </div>
            <div id="daerah-field" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['lg:col-span-3', 'hidden' => blank($filters['negeri'] ?? null)]); ?>">
                <label for="daerah" class="mb-1 block text-sm font-medium text-slate-700">Daerah</label>
                <select name="daerah" id="daerah" class="glass-input w-full rounded-xl px-3 py-2.5 text-sm">
                    <option value="">Semua daerah</option>
                    <?php $__currentLoopData = ($daerahByNegeri[$filters['negeri'] ?? ''] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daerah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($daerah); ?>" <?php if(($filters['daerah'] ?? '') === $daerah): echo 'selected'; endif; ?>><?php echo e($daerah); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p class="mt-1 text-xs text-slate-500">Senarai daerah AADK bagi negeri yang dipilih.</p>
            </div>
            <div class="flex flex-col gap-2 sm:flex-row lg:col-span-3">
                <button type="submit" class="glass-btn-primary inline-flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium">
                    <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    Papar Laporan
                </button>
                <a
                    href="<?php echo e(route('reports.pdf', array_filter(['jenis' => $filters['jenis'] ?? null, 'negeri' => $filters['negeri'] ?? null, 'daerah' => $filters['daerah'] ?? null]))); ?>"
                    class="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-2"
                >
                    <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Eksport PDF
                </a>
            </div>
        </div>
    </form>

    <div class="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <div class="glass-card p-4">
            <p class="text-2xl font-bold text-slate-900"><?php echo e(number_format($summary['permohonanBaharu'])); ?></p>
            <p class="mt-1 text-xs font-medium text-slate-500">Permohonan Baharu</p>
        </div>
        <div class="glass-card p-4">
            <p class="text-2xl font-bold text-slate-900"><?php echo e(number_format($summary['dalamTindakan'])); ?></p>
            <p class="mt-1 text-xs font-medium text-slate-500">Dalam Tindakan</p>
        </div>
        <div class="glass-card p-4">
            <p class="text-2xl font-bold text-slate-900"><?php echo e(number_format($summary['kontrakAktif'])); ?></p>
            <p class="mt-1 text-xs font-medium text-slate-500">Kontrak Aktif</p>
        </div>
        <div class="glass-card p-4">
            <p class="text-2xl font-bold text-amber-700"><?php echo e(number_format($summary['kontrakLapanBulan'])); ?></p>
            <p class="mt-1 text-xs font-medium text-slate-500">Bawah 8 Bulan</p>
        </div>
        <div class="glass-card border border-red-200/80 bg-red-50/70 p-4">
            <p class="text-2xl font-bold text-red-700"><?php echo e(number_format($summary['kontrakTigaBulan'])); ?></p>
            <p class="mt-1 text-xs font-medium text-red-700">Bawah 3 Bulan</p>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <section class="glass-card overflow-hidden p-5">
            <h2 class="text-sm font-semibold text-slate-900">Status Tindakan</h2>
            <p class="mt-0.5 text-xs text-slate-500">Bilangan permohonan mengikut status semasa</p>
            <div class="mt-4 space-y-2">
                <?php $__empty_1 = true; $__currentLoopData = $report['statusBreakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between gap-3 rounded-xl bg-slate-50/80 px-3 py-2 text-sm">
                        <span class="text-slate-700"><?php echo e($row['status']); ?></span>
                        <span class="font-semibold text-slate-900"><?php echo e(number_format($row['count'])); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-slate-500">Tiada permohonan dalam tindakan.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="glass-card overflow-hidden p-5">
            <h2 class="text-sm font-semibold text-slate-900">
                <?php echo e(($report['breakdownMode'] ?? 'negeri') === 'daerah' ? 'Pecahan Mengikut Daerah' : 'Pecahan Mengikut Negeri'); ?>

            </h2>
            <p class="mt-0.5 text-xs text-slate-500">Permohonan berbanding kontrak aktif</p>
            <div class="mt-4 overflow-x-auto">
                <table class="min-w-full text-left text-sm">
                    <thead>
                        <tr class="border-b border-slate-200 text-xs uppercase tracking-wide text-slate-500">
                            <th class="px-2 py-2 font-semibold"><?php echo e(($report['breakdownMode'] ?? 'negeri') === 'daerah' ? 'Daerah' : 'Negeri'); ?></th>
                            <th class="px-2 py-2 font-semibold">Permohonan</th>
                            <th class="px-2 py-2 font-semibold">Kontrak Aktif</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $report['negeriBreakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b border-slate-100">
                                <td class="px-2 py-2 text-slate-800"><?php echo e($row['label']); ?></td>
                                <td class="px-2 py-2 text-slate-700"><?php echo e(number_format($row['permohonan'])); ?></td>
                                <td class="px-2 py-2 text-slate-700"><?php echo e(number_format($row['kontrak_aktif'])); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="px-2 py-4 text-slate-500">Tiada data untuk dipaparkan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <section class="glass-card overflow-hidden">
        <div class="border-b border-slate-200/80 px-5 py-4">
            <h2 class="text-sm font-semibold text-slate-900">
                <?php if(($report['jenis'] ?? '') === \App\Services\HqReportService::TYPE_KONTRAK_NEGERI): ?>
                    <?php echo e(\App\Support\ContractNegeriReport::title($report['negeri'], $report['daerah'] ?? null)); ?>

                <?php elseif(($report['jenis'] ?? '') === \App\Services\HqReportService::TYPE_STATUS_SEWAAN): ?>
                    <?php echo e(\App\Support\RentalStatusReport::title()); ?>

                <?php else: ?>
                    <?php echo e($report['jenisLabel']); ?>

                <?php endif; ?>
            </h2>
            <?php if(($report['jenis'] ?? '') === \App\Services\HqReportService::TYPE_STATUS_SEWAAN): ?>
                <p class="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Lampiran 1</p>
            <?php endif; ?>
            <p class="mt-0.5 text-xs text-slate-500">
                Dijana pada <?php echo e($report['generatedAt']); ?>

                · Skop: <?php echo e($report['scopeLabel']); ?>

                · <?php echo e(number_format($rows->count())); ?> rekod
                <?php if(($report['jenis'] ?? '') === \App\Services\HqReportService::TYPE_KONTRAK_NEGERI): ?>
                    · Laporan secara individu beserta kronologi
                <?php endif; ?>
            </p>
        </div>
        <?php if(($report['jenis'] ?? '') === \App\Services\HqReportService::TYPE_KONTRAK_NEGERI): ?>
            <?php echo $__env->make('reports.partials.kontrak-negeri-table', ['rows' => $rows], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif(($report['jenis'] ?? '') === \App\Services\HqReportService::TYPE_STATUS_SEWAAN): ?>
            <?php echo $__env->make('reports.partials.status-sewaan-table', ['groups' => $report['statusGroups'] ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full text-left text-sm">
                    <thead class="bg-slate-50/80 text-xs uppercase tracking-wide text-slate-500">
                        <tr>
                            <th class="px-4 py-3 font-semibold">No.</th>
                            <th class="px-4 py-3 font-semibold">Premis</th>
                            <th class="px-4 py-3 font-semibold">Negeri</th>
                            <th class="px-4 py-3 font-semibold">Daerah</th>
                            <th class="px-4 py-3 font-semibold">Kategori</th>
                            <th class="px-4 py-3 font-semibold">Status</th>
                            <th class="px-4 py-3 font-semibold">Tarikh Tamat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-t border-slate-100">
                                <td class="px-4 py-3 text-slate-500"><?php echo e($index + 1); ?></td>
                                <td class="px-4 py-3 font-medium text-slate-900"><?php echo e($contract->premise?->nama_ptj ?? '–'); ?></td>
                                <td class="px-4 py-3 text-slate-700"><?php echo e($contract->premise?->negeri ?? '–'); ?></td>
                                <td class="px-4 py-3 text-slate-700"><?php echo e($contract->premise?->daerah ?: '–'); ?></td>
                                <td class="px-4 py-3 text-slate-700"><?php echo e(\App\Support\ApplicationCategories::label($contract->kategori_permohonan)); ?></td>
                                <td class="px-4 py-3 text-slate-700"><?php echo e($contract->workflowLabel()); ?></td>
                                <td class="px-4 py-3 text-slate-700">
                                    <?php
                                        $endDate = $contract->contractEndDate();
                                    ?>
                                    <?php echo e($endDate ? $endDate->format('d/m/Y') : '–'); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="px-4 py-8 text-center text-slate-500">Tiada rekod untuk laporan ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="application/json" id="aadk-daerah-data"><?php echo json_encode($daerahByNegeri, 15, 512) ?></script>
<script>
(function () {
    const negeriSelect = document.getElementById('negeri');
    const daerahField = document.getElementById('daerah-field');
    const daerahSelect = document.getElementById('daerah');
    const dataElement = document.getElementById('aadk-daerah-data');

    if (!negeriSelect || !daerahField || !daerahSelect || !dataElement) {
        return;
    }

    const daerahByNegeri = JSON.parse(dataElement.textContent || '{}');

    function fillDaerah(negeri, selected) {
        const options = daerahByNegeri[negeri] || [];
        daerahSelect.replaceChildren();

        const allOption = document.createElement('option');
        allOption.value = '';
        allOption.textContent = 'Semua daerah';
        daerahSelect.appendChild(allOption);

        options.forEach(function (name) {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            option.selected = name === selected;
            daerahSelect.appendChild(option);
        });
    }

    negeriSelect.addEventListener('change', function () {
        const negeri = negeriSelect.value;
        const show = negeri !== '';
        daerahField.classList.toggle('hidden', !show);
        fillDaerah(negeri, '');
    });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/reports/index.blade.php ENDPATH**/ ?>