<?php
    $empty = $empty ?? 'Tiada maklumat direkodkan.';
    $multiline = $multiline ?? false;
    $displayValue = filled($value ?? null) ? trim((string) $value) : null;
?>

<div <?php if(isset($wrapperClass)): ?> class="<?php echo e($wrapperClass); ?>" <?php endif; ?>>
    <p class="mb-1.5 text-xs font-semibold uppercase tracking-wide text-gray-500"><?php echo e($label); ?></p>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'glass-field-static text-sm text-slate-800',
        'min-h-[2.75rem] px-4 py-2.5 leading-relaxed' => ! $multiline,
        'min-h-[4.5rem] px-4 py-3.5 leading-6 whitespace-pre-wrap' => $multiline,
    ]); ?>"><?php if($displayValue !== null): ?><?php echo e($displayValue); ?><?php else: ?><span class="italic text-slate-400"><?php echo e($empty); ?></span><?php endif; ?></div>
</div>
<?php /**PATH D:\project\eSewaan\resources\views/partials/readonly-field.blade.php ENDPATH**/ ?>