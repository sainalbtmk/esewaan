<?php $__env->startSection('title', 'Set Semula Kata Laluan'); ?>

<?php $__env->startSection('content'); ?>
<div class="glass-card overflow-hidden p-7 sm:p-9">
    <div class="mb-7">
        <p class="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Kata laluan baharu</p>
        <h2 class="mt-2 text-2xl font-semibold text-slate-900">Set Semula Kata Laluan</h2>
        <p class="mt-1.5 text-sm text-slate-500">Masukkan kata laluan baharu untuk akaun anda.</p>
    </div>

    <form method="POST" action="<?php echo e(route('password.update')); ?>" class="space-y-5" data-no-global-loader>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($token); ?>">

        <div>
            <label for="email" class="mb-1.5 block text-sm font-medium text-slate-700">Emel</label>
            <input
                type="email"
                name="email"
                id="email"
                value="<?php echo e(old('email', $email)); ?>"
                required
                autofocus
                class="glass-input w-full rounded-xl px-3.5 py-2.5 text-sm"
                autocomplete="username"
            >
        </div>

        <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Kata laluan baharu','name' => 'password','inputId' => 'reset-password','autocomplete' => 'new-password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Kata laluan baharu','name' => 'password','input-id' => 'reset-password','autocomplete' => 'new-password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Sahkan kata laluan baharu','name' => 'password_confirmation','inputId' => 'reset-password-confirmation','autocomplete' => 'new-password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sahkan kata laluan baharu','name' => 'password_confirmation','input-id' => 'reset-password-confirmation','autocomplete' => 'new-password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>

        <button type="submit" class="glass-btn-primary w-full rounded-xl px-4 py-2.5 text-sm font-medium">
            Kemaskini Kata Laluan
        </button>
    </form>

    <p class="mt-6 text-center">
        <a href="<?php echo e(route('login')); ?>" class="text-sm font-medium text-slate-700 hover:text-slate-900">
            Kembali ke Log Masuk
        </a>
    </p>
</div>

<?php echo $__env->make('partials.auth-password-toggle-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>