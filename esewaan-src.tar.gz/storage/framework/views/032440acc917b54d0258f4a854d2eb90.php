<?php
    $p = $contract->premise;
    $steps = $contract->draftAgreementProgressSteps();
?>

<?php $__env->startSection('title', 'Butiran Kontrak Sewaan'); ?>
<?php $__env->startSection('header_title', 'Butiran Kontrak Sewaan'); ?>
<?php $__env->startSection('header_subtitle', $p?->nama_ptj ?? 'Maklumat kontrak sewaan'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4">
    <section class="glass-card scroll-mt-24 overflow-hidden" data-progress-steps="0" id="progress-step-0">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Maklumat Asas</h2>
            <p class="mt-0.5 text-xs text-slate-500">Ringkasan kategori, negeri dan pihak terlibat.</p>
        </div>
        <div class="grid grid-cols-1 gap-3 px-4 py-3 text-sm md:grid-cols-3">
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Kategori</p>
                <p class="mt-0.5 text-sm text-slate-800"><?php echo e(\App\Support\ApplicationCategories::label($contract->kategori_permohonan)); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Negeri</p>
                <p class="mt-0.5 text-sm text-slate-800"><?php echo e($p?->negeri ?? '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Nama Pemohon</p>
                <p class="mt-0.5 text-sm font-semibold text-slate-800"><?php echo e($contract->displayAdminNegeriName()); ?></p>
            </div>
        </div>
    </section>

    <section class="glass-card overflow-hidden">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Maklumat Premis & Pemilik</h2>
            <p class="mt-0.5 text-xs text-slate-500">Butiran premis, sewa dan pemilik.</p>
        </div>
        <div class="grid grid-cols-1 gap-3 px-4 py-3 text-sm md:grid-cols-2">
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Nama Premis</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($p?->nama_ptj ?? '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Jenis Bangunan</p>
                <p class="mt-0.5 text-slate-800"><?php echo e(\App\Support\BuildingTypes::all()[$p?->jenis_bangunan] ?? ($p?->jenis_bangunan ?? '–')); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Kadar Sewa (RM)</p>
                <p class="mt-0.5 text-slate-800"><?php echo e(number_format((float) ($p?->kadar_sewa ?? $contract->kadar_sewa_bulanan), 2)); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Keluasan (mps)</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->keluasan_mp ? number_format((float) $contract->keluasan_mp, 2) : '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Keluasan (kps)</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->keluasan_mp ? number_format((float) $contract->keluasan_mp * 10.7639, 2) : '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tarikh Mula</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->tarikh_mula_tawaran?->format('d/m/Y') ?? '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tarikh Akhir Tempoh Tawaran Penyewaan</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->sah_sehingga?->format('d/m/Y') ?? '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Nama Pemilik</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($p?->nama_pemilik ?? '–'); ?></p>
            </div>
            <div class="md:col-span-2">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Alamat Penuh Premis</p>
                <p class="mt-0.5 whitespace-pre-wrap text-slate-800"><?php echo e($p?->alamat_penuh ?? '–'); ?></p>
            </div>
        </div>
    </section>

    <section class="glass-card overflow-hidden">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Maklumat Kontrak</h2>
            <p class="mt-0.5 text-xs text-slate-500">Status dan tempoh kontrak sewaan yang telah disahkan.</p>
        </div>
        <div class="grid grid-cols-1 gap-3 px-4 py-3 text-sm md:grid-cols-2 lg:grid-cols-3">
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tarikh Disahkan Ibu Pejabat</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->hq_approved_at?->format('d/m/Y') ?? '–'); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Status</p>
                <p class="mt-0.5">
                    <span class="<?php echo e($contract->applicationStatusBadgeClass()); ?> inline-flex">
                        <?php echo e($contract->applicationStatusLabel(auth()->user())); ?>

                    </span>
                </p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Workflow</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->workflowLabel()); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tempoh Kontrak</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->contractPeriodLabel()); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Baki Tempoh</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->daysUntilContractEndLabel()); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tarikh Mula</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->usesPlaceholderContractDates() ? '–' : ($contract->tarikh_mula?->format('d/m/Y') ?? '–')); ?></p>
            </div>
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tarikh Tamat</p>
                <p class="mt-0.5 text-slate-800"><?php echo e($contract->usesPlaceholderContractDates() ? '–' : ($contract->tarikh_tamat?->format('d/m/Y') ?? '–')); ?></p>
            </div>
        </div>
    </section>

    <section class="glass-card" id="kemajuan-permohonan">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Kemajuan Permohonan</h2>
            <p class="mt-0.5 text-xs text-slate-500">Klik pada mana-mana langkah untuk pergi ke bahagian berkenaan.</p>
        </div>
        <div class="overflow-visible px-4 pb-6 pt-4">
            <?php echo $__env->make('status-permohonan.partials.progress-stepper', ['steps' => $steps], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    <?php if($contract->isFollowUpApplication()): ?>
        <section class="glass-card overflow-hidden">
            <div class="glass-divider-soft border-b px-4 py-3">
                <h2 class="text-base font-semibold text-slate-900">Perbandingan Permohonan</h2>
                <p class="mt-0.5 text-xs text-slate-500">Bandingkan maklumat kontrak lama dengan permohonan baharu.</p>
            </div>
            <div class="px-4 py-3">
                <?php echo $__env->make('partials.follow-up-comparison', ['contract' => $contract], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if(filled($contract->remark) && ! $contract->isFollowUpApplication()): ?>
        <section class="glass-card overflow-hidden">
            <div class="glass-divider-soft border-b px-4 py-3">
                <h2 class="text-base font-semibold text-slate-900">Remark</h2>
                <p class="mt-0.5 text-xs text-slate-500">Catatan tambahan berkaitan permohonan.</p>
            </div>
            <div class="px-4 py-3">
                <?php echo $__env->make('partials.readonly-field', [
                    'label' => 'Remark',
                    'value' => $contract->remark,
                    'multiline' => true,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="glass-card overflow-hidden">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Langkah Tindakan Pegawai Negeri</h2>
            <p class="mt-0.5 text-xs text-slate-500">Status kemajuan langkah tindakan yang telah dilengkapkan.</p>
        </div>
        <div class="px-4 py-3">
            <?php echo $__env->make('status-permohonan.partials.proceed-readonly', [
                'stepPanels' => $stepPanels,
                'completedCount' => $completedCount,
                'totalActiveSteps' => $totalActiveSteps,
                'compact' => true,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    <section class="glass-card scroll-mt-24 overflow-hidden" data-progress-steps="1" id="progress-step-1">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Pengesahan Ibu Pejabat</h2>
            <p class="mt-0.5 text-xs text-slate-500">Checklist JRP yang telah direkodkan oleh Ibu Pejabat.</p>
        </div>
        <div class="px-4 py-3">
            <?php echo $__env->make('status-permohonan.partials.hq-jrp-checklist-readonly', [
                'contract' => $contract,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php if(! is_array($contract->hq_jrp_checklist) || $contract->hq_jrp_checklist === []): ?>
                <p class="mt-3 text-sm text-slate-500">Tiada checklist JRP direkodkan untuk permohonan ini.</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="glass-card scroll-mt-24 overflow-hidden" data-progress-steps="2 3 4" id="progress-step-2">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Status Draf Perjanjian</h2>
            <p class="mt-0.5 text-xs text-slate-500">Rekod peringkat penyediaan dan semakan draf perjanjian.</p>
        </div>
        <div class="space-y-3 px-4 py-3 text-sm">
            <div>
                <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Status Semasa</p>
                <span class="<?php echo e($contract->applicationStatusBadgeClass()); ?> mt-1 inline-flex">
                    <?php echo e($contract->applicationStatusLabel(auth()->user())); ?>

                </span>
            </div>
            <?php if((int) $contract->semakan_count > 0): ?>
                <div>
                    <p class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Bilangan Semakan PUU</p>
                    <p class="mt-0.5 text-slate-800"><?php echo e($contract->semakanLabel()); ?></p>
                </div>
            <?php endif; ?>
            <?php echo $__env->make('status-permohonan.partials.draft-document-history', ['contract' => $contract], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <p class="text-sm text-slate-600">
                Draf perjanjian telah diluluskan dan tindakan Negeri serta pengesahan Ibu Pejabat telah selesai.
            </p>
            <div class="glass-subtle rounded-xl border border-slate-200/60 p-4">
                <p class="text-sm font-semibold text-slate-900">Tindakan Negeri</p>
                <p class="mt-0.5 text-xs text-slate-500">Pengesahan yang telah ditandakan.</p>
                <div class="mt-3">
                    <?php echo $__env->make('status-permohonan.partials.negeri-draft-acknowledgements-readonly', [
                        'contract' => $contract,
                        'acknowledgementsCompleted' => true,
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="glass-card scroll-mt-24 overflow-hidden" data-progress-steps="5" id="progress-step-5">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Pengesahan & Tandatangan</h2>
            <p class="mt-0.5 text-xs text-slate-500">Pengesahan penerimaan dan tandatangan perjanjian oleh Ibu Pejabat.</p>
        </div>
        <div class="px-4 py-3">
            <p class="text-sm text-emerald-700">Perjanjian telah disahkan dan dihantar kepada Negeri untuk Mati Setem.</p>
        </div>
    </section>

    <section class="glass-card scroll-mt-24 overflow-hidden" data-progress-steps="6" id="progress-step-6">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Mati Setem</h2>
            <p class="mt-0.5 text-xs text-slate-500">Pengesahan mati setem dan edaran dokumen oleh Negeri.</p>
        </div>
        <div class="px-4 py-3">
            <?php echo $__env->make('status-permohonan.partials.negeri-mati-setem-readonly', [
                'contract' => $contract,
                'acknowledgementsCompleted' => true,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    <section class="glass-card scroll-mt-24 overflow-hidden" data-progress-steps="7" id="progress-step-7">
        <div class="glass-divider-soft border-b px-4 py-3">
            <h2 class="text-base font-semibold text-slate-900">Selesai</h2>
            <p class="mt-0.5 text-xs text-slate-500">Permohonan selesai dan dimasukkan ke dalam Senarai Kontrak Sewaan.</p>
        </div>
        <div class="px-4 py-3">
            <p class="text-sm text-emerald-700">Permohonan telah selesai dan dimasukkan ke dalam Senarai Kontrak Sewaan.</p>
        </div>
    </section>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const buttons = Array.from(document.querySelectorAll('#kemajuan-permohonan [data-step-index]'));
    const sections = Array.from(document.querySelectorAll('[data-progress-steps]'));
    if (!buttons.length || !sections.length) {
        return;
    }

    function sectionForStep(index) {
        const key = String(index);

        return sections.find((section) => {
            return section.dataset.progressSteps
                .split(/\s+/)
                .filter(Boolean)
                .includes(key);
        }) ?? null;
    }

    function highlight(index) {
        buttons.forEach((button) => {
            const circle = button.querySelector('[data-step-circle]');
            const isActive = button.dataset.stepIndex === String(index);
            if (!circle) {
                return;
            }

            circle.classList.toggle('outline', isActive);
            circle.classList.toggle('outline-2', isActive);
            circle.classList.toggle('outline-offset-2', isActive);
            circle.classList.toggle('outline-indigo-400', isActive);
        });
    }

    buttons.forEach((button) => {
        button.addEventListener('click', (event) => {
            event.preventDefault();
            const index = button.dataset.stepIndex;
            const target = sectionForStep(index);
            if (!target) {
                return;
            }

            highlight(index);
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/kontrak-sewaan/show.blade.php ENDPATH**/ ?>