<?php $__env->startSection('title', 'Kemaskini Profil'); ?>
<?php $__env->startSection('header_title', 'Kemaskini Profil'); ?>
<?php $__env->startSection('header_subtitle', auth()->user()->name); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-2xl space-y-6">
    <div class="glass-card p-6">
        <h1 class="mb-6 text-xl font-bold text-slate-800">Kemaskini profil saya</h1>
        <form method="POST" action="<?php echo e(route('profile.update')); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label for="name" class="mb-1 block text-sm font-medium text-slate-700">Nama penuh</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" required
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="email" class="mb-1 block text-sm font-medium text-slate-700">Emel</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" required
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if(! $user->isAdminHq()): ?>
            <div>
                <label for="negeri" class="mb-1 block text-sm font-medium text-slate-700">Negeri</label>
                <?php if($canEditNegeri): ?>
                <select name="negeri" id="negeri"
                    class="glass-input w-full rounded-xl px-3 py-2 text-sm">
                    <option value="">— Pilih negeri —</option>
                    <?php $__currentLoopData = $negeriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(old('negeri', $user->negeri) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php else: ?>
                <p class="glass-field-static px-3 py-2 text-sm text-slate-700"><?php echo e($user->negeri ?? '–'); ?></p>
                <p class="mt-1 text-xs text-slate-500">Negeri ditetapkan oleh pentadbir dan tidak boleh diubah di sini.</p>
                <?php endif; ?>
                <?php $__errorArgs = ['negeri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">Peranan</label>
                <p class="glass-field-static px-3 py-2 text-sm text-slate-700"><?php echo e($user->roleLabel()); ?></p>
                <p class="mt-1 text-xs text-slate-500">Peranan hanya boleh diubah oleh pentadbir.</p>
            </div>
            <div class="rounded-lg border border-amber-200 bg-amber-50 p-4">
                <p class="mb-3 text-sm font-medium text-amber-900">Pengesahan dan kata laluan</p>
                <p class="mb-4 text-xs text-amber-800">Kata laluan semasa diperlukan jika emel atau kata laluan ditukar. Biarkan kata laluan baharu kosong jika tidak mahu menukarnya.</p>
                <div class="space-y-4">
                    <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Kata laluan semasa','name' => 'current_password','inputId' => 'profile-current-password','autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Kata laluan semasa','name' => 'current_password','input-id' => 'profile-current-password','autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Kata laluan baharu','name' => 'password','inputId' => 'profile-password','autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Kata laluan baharu','name' => 'password','input-id' => 'profile-password','autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal2416423cd7a347b77df41c467875b004 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2416423cd7a347b77df41c467875b004 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.password-field','data' => ['label' => 'Sahkan kata laluan baharu','name' => 'password_confirmation','inputId' => 'profile-password-confirm','autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.password-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sahkan kata laluan baharu','name' => 'password_confirmation','input-id' => 'profile-password-confirm','autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $attributes = $__attributesOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__attributesOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2416423cd7a347b77df41c467875b004)): ?>
<?php $component = $__componentOriginal2416423cd7a347b77df41c467875b004; ?>
<?php unset($__componentOriginal2416423cd7a347b77df41c467875b004); ?>
<?php endif; ?>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="flex flex-wrap gap-3 pt-2">
                <button type="submit" class="glass-btn-primary rounded-xl px-4 py-2.5 text-sm font-medium">
                    Simpan perubahan
                </button>
                <a href="<?php echo e(route('profile.show')); ?>" class="glass-btn-secondary rounded-xl px-4 py-2.5 text-sm font-medium">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>
<?php echo $__env->make('partials.auth-password-toggle-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\eSewaan\resources\views/profile/edit.blade.php ENDPATH**/ ?>