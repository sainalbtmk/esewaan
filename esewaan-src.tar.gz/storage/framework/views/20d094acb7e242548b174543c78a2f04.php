<section id="emel-jawatan" class="glass-card glass-table overflow-hidden">
    <div class="glass-divider-soft border-b px-4 py-3">
        <h2 class="text-base font-semibold text-slate-900">Salinan Emel Jawatan</h2>
        <p class="mt-0.5 text-xs text-slate-500">Emel ini disalin pada amaran kontrak yang berbaki 3 bulan. Tukar emel di sini jika penyandang jawatan bertukar.</p>
    </div>
    <form method="POST" action="<?php echo e(route('users.emel-jawatan.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="glass-divider-soft border-b bg-white/40">
                        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Nama Jawatan</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Emel</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__currentLoopData = $emelJawatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-3 font-medium text-slate-800"><?php echo e($jawatan->nama_jawatan); ?></td>
                            <td class="px-4 py-3">
                                <label for="emel-jawatan-<?php echo e($jawatan->kod); ?>" class="sr-only">Emel <?php echo e($jawatan->nama_jawatan); ?></label>
                                <input
                                    type="email"
                                    id="emel-jawatan-<?php echo e($jawatan->kod); ?>"
                                    name="emails[<?php echo e($jawatan->kod); ?>]"
                                    value="<?php echo e(old('emails.'.$jawatan->kod, $jawatan->email)); ?>"
                                    required
                                    autocomplete="off"
                                    class="glass-input w-full max-w-md rounded-xl px-3 py-2 text-sm"
                                >
                                <?php $__errorArgs = ['emails.'.$jawatan->kod];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="glass-divider-soft border-t px-4 py-3">
            <button type="submit" class="glass-btn-primary rounded-xl px-4 py-2.5 text-sm font-medium">
                Simpan emel
            </button>
        </div>
    </form>
</section>
<?php /**PATH D:\project\eSewaan\resources\views/users/partials/emel-jawatan.blade.php ENDPATH**/ ?>