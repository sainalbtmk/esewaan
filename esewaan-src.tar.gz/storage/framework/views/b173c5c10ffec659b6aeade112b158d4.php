<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->isAdmin()): ?>
            <meta name="sidebar-notifications-url" content="<?php echo e(route('sidebar-notifications')); ?>">
        <?php endif; ?>
    <?php endif; ?>
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title', 'SPEKTRA'); ?></title>
    <link rel="icon" href="<?php echo e(asset('favicon.png') . '?v=' . filemtime(public_path('favicon.png'))); ?>" type="image/png">
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png') . '?v=' . filemtime(public_path('favicon.png'))); ?>">
    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600,700" rel="stylesheet">
    <?php echo $__env->make('partials.appearance-boot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.sidebar-scroll-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.glass-theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.appearance-theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.corporate-theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'min-h-screen font-sans antialiased',
    'liquid-bg' => auth()->check(),
    'corp-app' => auth()->check(),
    'corp-auth' => request()->routeIs('login'),
    'corp-guest' => ! auth()->check() && ! request()->routeIs('login'),
]); ?>">
    <?php echo $__env->make('partials.global-loading-overlay', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="liquid-bg-mesh" aria-hidden="true">
        <div class="liquid-orb liquid-orb-1"></div>
        <div class="liquid-orb liquid-orb-2"></div>
        <div class="liquid-orb liquid-orb-3"></div>
    </div>
    <?php if(auth()->guard()->check()): ?>
    <div class="flex h-screen overflow-hidden">
        
        <aside id="sidebar" class="glass-sidebar hidden lg:flex h-full min-h-0 w-60 flex-shrink-0 flex-col overflow-hidden transition-all duration-300">
            <div class="flex h-full min-h-0 flex-col">
                <div class="flex flex-shrink-0 items-center border-b border-white/10 px-3 py-3">
                    <?php
                        $logoPath = null;
                        $custom = config('app.logo');
                        if ($custom && file_exists(public_path($custom))) {
                            $logoPath = $custom;
                        } else {
                            foreach (['images/spektra-logo.jpg', 'aadk.png', 'logo.png', 'logo.jpg', 'logo.jpeg', 'logo.webp', 'images/logo.png', 'images/logo.jpg', 'images/logo.jpeg', 'images/logo.webp'] as $name) {
                                if (file_exists(public_path($name))) {
                                    $logoPath = $name;
                                    break;
                                }
                            }
                        }
                    ?>
                    <?php if($logoPath): ?>
                        <img src="<?php echo e(asset($logoPath)); ?>" alt="SPEKTRA" class="h-auto w-full rounded-lg bg-white object-contain p-1.5">
                    <?php else: ?>
                        <div>
                            <p class="text-sm font-semibold leading-tight text-white">SPEKTRA</p>
                            <p class="text-xs leading-snug text-white/50">Sistem Pemantauan Kontrak Sewaan Premis AADK</p>
                        </div>
                    <?php endif; ?>
                </div>
                <nav class="sidebar-scroll min-h-0 flex-1 space-y-1 overflow-y-auto overscroll-y-contain px-3 py-4 pr-2 scroll-smooth">
                    <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-nav-link <?php echo e(request()->routeIs('dashboard') ? 'is-active' : ''); ?>">
                        <svg class="w-5 h-5 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>
                        <span>Papan Pemuka</span>
                    </a>
                    <?php endif; ?>
                    <?php if(auth()->user()->isAdmin()): ?>
                    <?php echo $__env->make('partials.sidebar-pengurusan-permohonan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.sidebar-kontrak-sewaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.sidebar-jana-laporan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.sidebar-pengurusan-pengguna', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php else: ?>
                    <?php echo $__env->make('partials.sidebar-kontrak-sewaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                </nav>
                <?php echo $__env->make('partials.sidebar-profile-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </aside>

        
        <div id="mobile-sidebar-overlay" class="lg:hidden fixed inset-0 z-40 hidden">
            <div class="fixed inset-0 bg-black/50" id="mobile-overlay-backdrop"></div>
            <aside class="glass-sidebar relative z-50 flex h-full min-h-0 w-64 flex-col overflow-hidden shadow-xl">
                <div class="flex flex-shrink-0 items-center justify-between gap-3 border-b border-white/10 px-3 py-3">
                    <div class="min-w-0 flex-1">
                        <?php if($logoPath): ?>
                            <img src="<?php echo e(asset($logoPath)); ?>" alt="SPEKTRA" class="h-auto w-full rounded-lg bg-white object-contain p-1.5">
                        <?php else: ?>
                            <p class="text-sm font-semibold text-white">SPEKTRA</p>
                            <p class="text-xs text-white/50">Sistem Pemantauan Kontrak Sewaan Premis AADK</p>
                        <?php endif; ?>
                    </div>
                    <button type="button" id="mobile-close-sidebar" class="p-2 text-white/60 hover:text-white">&times;</button>
                </div>
                <nav class="sidebar-scroll min-h-0 flex-1 space-y-1 overflow-y-auto overscroll-y-contain px-3 py-4 pr-2 scroll-smooth">
                    <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-nav-link <?php echo e(request()->routeIs('dashboard') ? 'is-active' : ''); ?>">
                        <svg class="h-5 w-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                        </svg>
                        <span>Papan Pemuka</span>
                    </a>
                    <?php endif; ?>
                    <?php if(auth()->user()->isAdmin()): ?>
                    <?php echo $__env->make('partials.sidebar-pengurusan-permohonan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.sidebar-kontrak-sewaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.sidebar-jana-laporan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('partials.sidebar-pengurusan-pengguna', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php else: ?>
                    <?php echo $__env->make('partials.sidebar-kontrak-sewaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                </nav>
                <?php echo $__env->make('partials.sidebar-profile-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </aside>
        </div>

        <?php echo $__env->make('partials.sidebar-state', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="flex min-h-0 flex-1 flex-col min-w-0">
            <header class="glass-header relative z-30 flex h-20 flex-shrink-0 items-center justify-between px-4 lg:px-6">
                <div class="flex items-center gap-3">
                    <button type="button" id="mobile-open-sidebar" class="lg:hidden p-2 rounded-xl glass-subtle hover:bg-white/60 transition-colors">
                        <svg class="w-5 h-5 text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
                    </button>
                    <div>
                        <h1 class="text-base font-semibold text-slate-900"><?php echo $__env->yieldContent('header_title', 'SPEKTRA'); ?></h1>
                        <p class="text-xs text-slate-500 hidden sm:block"><?php echo $__env->yieldContent('header_subtitle', 'Sistem Pemantauan Kontrak Sewaan Premis AADK'); ?></p>
                    </div>
                </div>
                <?php if(auth()->user()->isAdmin()): ?>
                    <?php echo $__env->make('partials.header-inbox', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </header>

            <main class="min-h-0 flex-1 overflow-y-auto">
                <div class="p-4 lg:p-6">
                    <?php if(session('success')): ?>
                    <div class="mb-4 rounded-xl glass-alert-success p-4 text-green-800 text-sm" role="alert"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                    <div class="mb-4 rounded-xl glass-alert-error p-4 text-red-800 text-sm" role="alert"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <?php if(isset($errors) && $errors->any()): ?>
                    <div class="mb-4 rounded-xl glass-alert-warning p-4 text-amber-900 text-sm">
                        <ul class="list-inside list-disc"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                    </div>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        document.getElementById('mobile-open-sidebar')?.addEventListener('click', function() {
            document.getElementById('mobile-sidebar-overlay').classList.remove('hidden');
        });
        function closeMobileSidebar() {
            document.getElementById('mobile-sidebar-overlay').classList.add('hidden');
        }
        document.getElementById('mobile-close-sidebar')?.addEventListener('click', closeMobileSidebar);
        document.getElementById('mobile-overlay-backdrop')?.addEventListener('click', closeMobileSidebar);
    </script>
    <?php echo $__env->make('partials.sidebar-notifications-poll', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.list-interaction', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
    <?php if(request()->routeIs('login')): ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php else: ?>
    <?php
        $guestLogoPath = null;
        $custom = config('app.logo');
        if ($custom && file_exists(public_path($custom))) {
            $guestLogoPath = $custom;
        } else {
            foreach (['images/spektra-logo.jpg', 'aadk.png', 'logo.png', 'logo.jpg', 'logo.jpeg', 'logo.webp', 'images/logo.png', 'images/logo.jpg', 'images/logo.jpeg', 'images/logo.webp'] as $name) {
                if (file_exists(public_path($name))) {
                    $guestLogoPath = $name;
                    break;
                }
            }
        }
    ?>
    <div class="corp-guest">
        <header class="corp-header">
            <a href="<?php echo e(route('login')); ?>" class="corp-lockup">
                <?php if($guestLogoPath): ?>
                    <img src="<?php echo e(asset($guestLogoPath)); ?>" alt="SPEKTRA" class="corp-logo">
                <?php else: ?>
                    <div>
                        <p class="corp-system">SPEKTRA</p>
                        <p class="corp-agency">Agensi Antidadah Kebangsaan</p>
                    </div>
                <?php endif; ?>
            </a>
            <a href="<?php echo e(route('login')); ?>" class="corp-guest-login">Log Masuk</a>
        </header>
        <div class="corp-rule" aria-hidden="true"></div>
        <main class="corp-guest-main">
            <div>
                <?php if(session('success')): ?><div class="mb-4 glass-alert-success p-4 text-sm text-green-800"><?php echo e(session('success')); ?></div><?php endif; ?>
                <?php if(session('error')): ?><div class="mb-4 glass-alert-error p-4 text-sm text-red-800"><?php echo e(session('error')); ?></div><?php endif; ?>
                <?php if(isset($errors) && $errors->any()): ?><div class="mb-4 glass-alert-warning p-4 text-sm text-amber-900"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
        <footer class="corp-guest-footer">
            <span>© <?php echo e(date('Y')); ?> Agensi Antidadah Kebangsaan. Hak cipta terpelihara.</span>
            <span>Sistem rasmi kegunaan dalaman</span>
        </footer>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        document.addEventListener('submit', function (event) {
            var form = event.target;
            if (!(form instanceof HTMLFormElement)) {
                return;
            }
            var message = form.getAttribute('data-confirm');
            if (message && ! window.confirm(message)) {
                event.preventDefault();
            }
        }, true);

        document.addEventListener('click', function (event) {
            var trigger = event.target instanceof Element ? event.target.closest('[data-confirm-click]') : null;
            if (! trigger) {
                return;
            }
            var message = trigger.getAttribute('data-confirm-click');
            if (message && ! window.confirm(message)) {
                event.preventDefault();
            }
        }, true);
    </script>
</body>
</html>
<?php /**PATH D:\project\eSewaan\resources\views/layouts/app.blade.php ENDPATH**/ ?>