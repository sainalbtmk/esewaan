<?php
    use App\Support\ContractNegeriReport;
?>

<table class="data wide">
    <thead>
        <tr>
            <th>No</th>
            <th>Negeri</th>
            <th>Daerah</th>
            <th>PTJ</th>
            <th>Alamat</th>
            <th>Jenis Bangunan</th>
            <th>Mula</th>
            <th>Tamat</th>
            <th>Baki Bulan</th>
            <th>Keluasan (mp)</th>
            <th>Kadar Sewa</th>
            <th>Pemilik</th>
            <th>Kategori</th>
            <th>Status Permohonan</th>
            <th>Perincian Proses Cawangan Pembangunan</th>
            <th>Rumusan Status Terkini</th>
            <th>Tindakan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $kronologi = $contract->laporan_kronologi ?? [];
                $bakiClass = match (true) {
                    ContractNegeriReport::isBakiHariKritikal($contract) => 'baki-kritikal',
                    ContractNegeriReport::isBakiHariAmaran($contract) => 'baki-amaran',
                    default => '',
                };
                $statusClass = ContractNegeriReport::isStatusDiterima($contract) ? 'status-terima' : 'status-lain';
                $bakiBulan = ContractNegeriReport::bakiBulan($contract);
            ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($contract->premise?->negeri ?? '–'); ?></td>
                <td><?php echo e($contract->premise?->daerah ?: '–'); ?></td>
                <td><?php echo e($contract->premise?->nama_ptj ?? '–'); ?></td>
                <td class="pre"><?php echo e($contract->premise?->alamat_penuh ?: '–'); ?></td>
                <td><?php echo e(ContractNegeriReport::jenisLangganan($contract)); ?></td>
                <td><?php echo e(ContractNegeriReport::mula($contract)); ?></td>
                <td><?php echo e(ContractNegeriReport::tamat($contract)); ?></td>
                <td class="<?php echo e($bakiClass); ?>"><?php echo e($bakiBulan === null ? '–' : number_format($bakiBulan)); ?></td>
                <td><?php echo e(ContractNegeriReport::keluasan($contract)); ?></td>
                <td><?php echo e(ContractNegeriReport::kadarSewa($contract)); ?></td>
                <td><?php echo e($contract->premise?->nama_pemilik ?: '–'); ?></td>
                <td class="kategori"><?php echo e(ContractNegeriReport::kategoriLabel($contract)); ?></td>
                <td class="<?php echo e($statusClass); ?>"><?php echo e(ContractNegeriReport::statusPermohonan($contract)); ?></td>
                <td class="pre"><?php echo e($kronologi === [] ? 'Tiada kronologi.' : implode("\n", $kronologi)); ?></td>
                <td><?php echo e(ContractNegeriReport::rumusan($contract)); ?></td>
                <td><?php echo e(ContractNegeriReport::tindakan($contract)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="17" class="muted">Tiada rekod untuk laporan ini.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\project\eSewaan\resources\views/reports/partials/kontrak-negeri-pdf-table.blade.php ENDPATH**/ ?>