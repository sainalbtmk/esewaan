<?php
    $totalActiveSteps = $totalActiveSteps ?? count($stepPanels ?? []);
    $completedCount = $completedCount ?? 0;
    $progressPercent = $totalActiveSteps > 0 ? (int) round(($completedCount / $totalActiveSteps) * 100) : 0;
    $compact = $compact ?? false;
?>

<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['space-y-6' => ! $compact, 'space-y-3' => $compact]); ?>">
    <div>
        <div class="mb-2 flex items-center justify-between text-xs">
            <span class="font-medium text-slate-700">Kemajuan Langkah Tindakan</span>
            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-semibold text-emerald-700' => $progressPercent >= 100, 'text-slate-500' => $progressPercent < 100]); ?>">
                <?php echo e($completedCount); ?> / <?php echo e($totalActiveSteps); ?> langkah (<?php echo e($progressPercent); ?>%)
            </span>
        </div>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['overflow-hidden rounded-full glass-progress-track', 'h-1.5' => ! $compact, 'h-1' => $compact]); ?>">
            <div
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'h-full rounded-full transition-all duration-300',
                    'glass-progress-fill-emerald' => $progressPercent >= 100,
                    'glass-progress-fill-amber' => $progressPercent > 0 && $progressPercent < 100,
                    'glass-progress-fill' => $progressPercent === 0,
                ]); ?>"
                style="width: <?php echo e($progressPercent); ?>%"
            ></div>
        </div>
    </div>

    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['space-y-5' => ! $compact, 'space-y-2' => $compact]); ?>">
        <?php $__currentLoopData = $stepPanels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'glass-subtle rounded-2xl border border-slate-200/60',
                'p-5' => ! $compact,
                'rounded-xl p-3' => $compact,
            ]); ?>">
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4 flex flex-wrap items-start justify-between gap-3' => ! $compact, 'mb-2 flex flex-wrap items-start justify-between gap-2' => $compact]); ?>">
                    <div class="min-w-0 flex-1">
                        <p class="text-[11px] font-medium uppercase tracking-wide text-slate-500">
                            Langkah <?php echo e($panel['position']); ?> / <?php echo e($totalActiveSteps); ?>

                        </p>
                        <h3 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-1 font-semibold text-slate-900', 'text-base' => ! $compact, 'text-sm' => $compact]); ?>"><?php echo e($panel['title']); ?></h3>
                        <?php if (! ($compact)): ?>
                        <p class="mt-2 text-sm leading-relaxed text-slate-600"><?php echo e($panel['description']); ?></p>
                        <?php endif; ?>
                    </div>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'inline-flex shrink-0 items-center rounded-lg px-2.5 py-1 text-xs font-medium',
                        'bg-emerald-100 text-emerald-800' => $panel['completed'],
                        'bg-amber-100 text-amber-800' => ! $panel['completed'],
                    ]); ?>">
                        <?php echo e($panel['completed'] ? 'Selesai' : 'Belum selesai'); ?>

                    </span>
                </div>

                <?php if($panel['has_agency_checklist']): ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4 rounded-xl border border-slate-300 bg-white/40 p-4' => ! $compact, 'mb-2 rounded-lg border border-slate-300 bg-white/40 p-2' => $compact]); ?>">
                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['space-y-2' => ! $compact, 'space-y-1' => $compact]); ?>">
                            <?php $__currentLoopData = \App\Support\AdminProceedSteps::agencyDefinitions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agencyKey => $agencyLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $agencyChecked = ($panel['agencies'][$agencyKey] ?? false) === true;
                                    $agencyRequiresDate = \App\Support\AdminProceedSteps::agencyRequiresDate($agencyKey);
                                    $agencyDate = $panel['agency_dates'][$agencyKey] ?? null;
                                ?>
                                <div class="flex flex-col gap-2 rounded-lg border border-slate-300 bg-white/50 px-3 py-2 sm:flex-row sm:items-center sm:justify-between">
                                    <label class="flex min-w-0 items-start gap-3">
                                        <input
                                            type="checkbox"
                                            disabled
                                            <?php if($agencyChecked): echo 'checked'; endif; ?>
                                            class="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-slate-800"
                                        >
                                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-sm', 'text-slate-800' => $agencyChecked, 'text-slate-500' => ! $agencyChecked]); ?>">
                                            <?php echo e($agencyLabel); ?>

                                        </span>
                                    </label>
                                    <?php if($agencyRequiresDate && $agencyChecked): ?>
                                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'ml-7 text-xs text-slate-600 sm:ml-0 sm:text-sm',
                                            'font-medium text-slate-800' => filled($agencyDate),
                                        ]); ?>">
                                            <?php echo e(filled($agencyDate) ? \Illuminate\Support\Carbon::parse($agencyDate)->format('d/m/Y') : 'Tiada tarikh'); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($panel['requires_reference'] ?? false): ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mb-4 grid grid-cols-1 gap-3 sm:grid-cols-2' => ! $compact, 'mb-2 grid grid-cols-1 gap-2 sm:grid-cols-2' => $compact]); ?>">
                        <?php echo $__env->make('partials.readonly-field', [
                            'label' => 'No. Rujukan',
                            'value' => $panel['no_rujukan'] ?? null,
                            'empty' => 'Tiada no. rujukan direkodkan.',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php echo $__env->make('partials.readonly-field', [
                            'label' => 'Tarikh Surat',
                            'value' => filled($panel['tarikh_surat'] ?? null)
                                ? \Illuminate\Support\Carbon::parse($panel['tarikh_surat'])->format('d/m/Y')
                                : null,
                            'empty' => 'Tiada tarikh surat direkodkan.',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endif; ?>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['border-t border-slate-200/60 pt-4' => ! $compact, 'border-t border-slate-200/60 pt-2' => $compact]); ?>">
                    <p class="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Pengesahan Pentadbir Negeri</p>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['space-y-3' => ! $compact, 'space-y-1.5' => $compact]); ?>">
                        <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex items-start gap-3.5 rounded-xl border border-slate-300 bg-white/40 px-4 py-3.5' => ! $compact, 'flex items-start gap-2 rounded-lg border border-slate-300 bg-white/40 px-2 py-1.5' => $compact]); ?>">
                            <input
                                type="checkbox"
                                disabled
                                <?php if($panel['confirmed_accurate'] ?? false): echo 'checked'; endif; ?>
                                class="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-slate-800"
                            >
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['leading-relaxed text-slate-700', 'text-sm' => ! $compact, 'text-xs' => $compact]); ?>">
                                <span class="font-medium text-slate-900">
                                    <?php if(($panel['position'] ?? null) === 1): ?>
                                        Saya mengesahkan surat niat telah dihantar ke pemilik premis
                                    <?php elseif(($panel['key'] ?? null) === \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?>
                                        Saya mengesahkan borang JRP telah diisi dan dimuat naik ke PROMIS
                                    <?php else: ?>
                                        Saya mengesahkan maklumat ini tepat dan benar
                                    <?php endif; ?>
                                </span>
                            </span>
                        </label>

                        <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex items-start gap-3.5 rounded-xl border border-slate-300 bg-white/40 px-4 py-3.5' => ! $compact, 'flex items-start gap-2 rounded-lg border border-slate-300 bg-white/40 px-2 py-1.5' => $compact]); ?>">
                            <input
                                type="checkbox"
                                disabled
                                <?php if($panel['confirmed_promis'] ?? false): echo 'checked'; endif; ?>
                                class="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-slate-800"
                            >
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['leading-relaxed text-slate-700', 'text-sm' => ! $compact, 'text-xs' => $compact]); ?>">
                                <span class="font-medium text-slate-900">
                                    <?php if(($panel['position'] ?? null) === 1): ?>
                                        Surat tawaran pemilik premis telah diterima dan dimuat naik ke PROMIS
                                    <?php elseif(($panel['key'] ?? null) === \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?>
                                        Saya mengesahkan maklumat ini tepat dan benar
                                    <?php else: ?>
                                        Maklumat ini telah dimuat naik ke dalam sistem PROMIS.
                                    <?php endif; ?>
                                </span>
                            </span>
                        </label>

                        <?php if(($panel['key'] ?? null) !== \App\Support\AdminProceedSteps::STEP_BORANG_JRP): ?>
                        <label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex items-start gap-3.5 rounded-xl border border-slate-300 bg-white/40 px-4 py-3.5' => ! $compact, 'flex items-start gap-2 rounded-lg border border-slate-300 bg-white/40 px-2 py-1.5' => $compact]); ?>">
                            <input
                                type="checkbox"
                                disabled
                                <?php if($panel['completed']): echo 'checked'; endif; ?>
                                class="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-slate-800"
                            >
                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['leading-relaxed text-slate-700', 'text-sm' => ! $compact, 'text-xs' => $compact]); ?>">
                                <span class="font-medium text-slate-900">Saya mengesahkan langkah ini telah selesai dilaksanakan.</span>
                            </span>
                        </label>
                        <?php endif; ?>
                    </div>
                </div>

                <?php echo $__env->make('partials.readonly-field', [
                    'label' => 'Catatan',
                    'value' => $panel['notes'] ?? null,
                    'multiline' => true,
                    'empty' => 'Tiada catatan direkodkan untuk langkah ini.',
                    'wrapperClass' => 'mt-5',
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\project\eSewaan\resources\views/status-permohonan/partials/proceed-readonly.blade.php ENDPATH**/ ?>