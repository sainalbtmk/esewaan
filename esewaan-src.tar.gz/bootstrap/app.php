<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Session\TokenMismatchException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => \App\Http\Middleware\EnsureUserIsAdmin::class,
            'admin.hq' => \App\Http\Middleware\EnsureUserIsAdminHq::class,
            'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
        ]);
        $middleware->appendToGroup('web', \App\Http\Middleware\SecurityHeaders::class);
        $middleware->appendToGroup('web', \App\Http\Middleware\EnsureUserIsActive::class);
        $middleware->appendToGroup('web', \App\Http\Middleware\EnsureContractInUserNegeri::class);
        $middleware->appendToGroup('web', \App\Http\Middleware\EnsureTwoFactorIsConfirmed::class);
        $middleware->authenticateSessions();
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->renderable(function (TokenMismatchException $e, Request $request) {
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Sesi tamat atau token tidak sah. Sila muat semula halaman.',
                ], 419);
            }

            return redirect()
                ->guest(route('login'))
                ->with('error', 'Sesi tamat atau tidak sah. Sila log masuk semula.');
        });

        $exceptions->renderable(function (TooManyRequestsHttpException $e, Request $request) {
            $retryAfter = $e->getHeaders()['Retry-After'] ?? 60;

            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Terlalu banyak permintaan. Sila tunggu '.$retryAfter.' saat dan cuba lagi.',
                ], 429);
            }

            return redirect()->back()
                ->with('error', 'Terlalu banyak permintaan. Sila tunggu sebentar dan cuba lagi.');
        });
    })->create();
